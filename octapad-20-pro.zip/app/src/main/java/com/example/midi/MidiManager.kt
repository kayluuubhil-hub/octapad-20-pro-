package com.example.midi

import android.content.Context
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager as AndroidMidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.example.data.model.MidiConfig
import com.example.data.model.MidiStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class MidiManager(
    private val context: Context,
    private val onPadNoteTriggered: (padIndex: Int, velocity: Float, midiNote: Int) -> Unit
) {

    private val isMidiSupported: Boolean =
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_MIDI)

    private val androidMidiManager: AndroidMidiManager? =
        if (isMidiSupported) context.getSystemService(Context.MIDI_SERVICE) as? AndroidMidiManager else null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val openDevices = mutableMapOf<Int, MidiDevice>()
    private val openPorts = mutableMapOf<Int, MutableList<MidiOutputPort>>()

    @Volatile
    private var midiConfig: MidiConfig = MidiConfig()

    private val _midiStatus = MutableStateFlow(
        MidiStatus(
            isSupported = isMidiSupported,
            isConnected = false,
            connectedDevices = emptyList()
        )
    )
    val midiStatus: StateFlow<MidiStatus> = _midiStatus.asStateFlow()

    private val deviceCallback = object : AndroidMidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) {
            if (device.outputPortCount > 0) {
                openMidiDevice(device)
            }
        }

        override fun onDeviceRemoved(device: MidiDeviceInfo) {
            closeMidiDevice(device.id)
        }
    }

    fun start() {
        val manager = androidMidiManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            manager.registerDeviceCallback(
                AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM,
                { r -> mainHandler.post(r) },
                deviceCallback
            )
            manager.getDevicesForTransport(AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM)
                .filter { it.outputPortCount > 0 }
                .forEach { openMidiDevice(it) }
        } else {
            @Suppress("DEPRECATION")
            manager.registerDeviceCallback(deviceCallback, mainHandler)
            @Suppress("DEPRECATION")
            manager.devices
                .filter { it.outputPortCount > 0 }
                .forEach { openMidiDevice(it) }
        }
        refreshConnectionState()
    }

    fun updateConfig(config: MidiConfig) {
        midiConfig = config
    }

    private fun openMidiDevice(info: MidiDeviceInfo) {
        val manager = androidMidiManager ?: return
        if (openDevices.containsKey(info.id)) return
        manager.openDevice(info, { device ->
            if (device != null) {
                openDevices[info.id] = device
                val ports = mutableListOf<MidiOutputPort>()
                for (portIndex in 0 until info.outputPortCount) {
                    val outputPort = device.openOutputPort(portIndex)
                    if (outputPort != null) {
                        outputPort.connect(createReceiver())
                        ports.add(outputPort)
                    }
                }
                openPorts[info.id] = ports
                refreshConnectionState()
            }
        }, mainHandler)
    }

    private fun closeMidiDevice(deviceId: Int) {
        openPorts.remove(deviceId)?.forEach { port ->
            try {
                port.close()
            } catch (_: Exception) {
            }
        }
        openDevices.remove(deviceId)?.let { dev ->
            try {
                dev.close()
            } catch (_: Exception) {
            }
        }
        refreshConnectionState()
    }

    private fun refreshConnectionState() {
        val names = openDevices.values.mapNotNull { dev ->
            val props = dev.info.properties
            props.getString(MidiDeviceInfo.PROPERTY_NAME)
                ?: props.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
                ?: "USB MIDI Controller"
        }
        _midiStatus.update {
            it.copy(
                isSupported = isMidiSupported,
                isConnected = openPorts.values.any { ports -> ports.isNotEmpty() },
                connectedDevices = names
            )
        }
    }

    private fun createReceiver(): MidiReceiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            parseMidiBytes(msg, offset, count)
        }
    }

    internal fun parseMidiBytes(msg: ByteArray, offset: Int, count: Int) {
        var i = offset
        val end = (offset + count).coerceAtMost(msg.size)
        while (i < end) {
            val status = msg[i].toInt() and 0xFF
            if (status in 0x90..0x9F && i + 2 < end) {
                val note = msg[i + 1].toInt() and 0x7F
                val velocityByte = msg[i + 2].toInt() and 0x7F
                if (velocityByte > 0) {
                    val padIndex = midiConfig.noteToPad[note]
                    if (padIndex != null && padIndex in 0..7) {
                        val vel = (velocityByte / 127f).coerceIn(0.05f, 1.0f)
                        onPadNoteTriggered(padIndex, vel, note)
                        _midiStatus.update {
                            it.copy(lastNote = note, lastPadTriggered = padIndex)
                        }
                    } else {
                        _midiStatus.update {
                            it.copy(lastNote = note, lastPadTriggered = null)
                        }
                    }
                }
                i += 3
            } else if (status in 0x80..0xEF && i + 2 < end) {
                i += 3
            } else {
                i += 1
            }
        }
    }

    fun stop() {
        androidMidiManager?.unregisterDeviceCallback(deviceCallback)
        openPorts.values.flatten().forEach {
            try {
                it.close()
            } catch (_: Exception) {
            }
        }
        openPorts.clear()
        openDevices.values.forEach {
            try {
                it.close()
            } catch (_: Exception) {
            }
        }
        openDevices.clear()
        refreshConnectionState()
    }
}
