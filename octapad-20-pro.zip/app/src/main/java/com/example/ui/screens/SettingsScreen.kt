package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.backup.RestoreMode
import com.example.data.model.AudioEffectsConfig
import com.example.ui.components.BackupRestoreConfirmDialog
import com.example.ui.components.ExternalImportOutcomeDialog
import com.example.ui.theme.BezelBorder
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ControlRaised
import com.example.ui.theme.LedAmber
import com.example.ui.theme.LedCyan
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.RackSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.OctapadUiState
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    uiState: OctapadUiState,
    onMasterVolumeChange: (Float) -> Unit,
    onPadVolumeChange: (Int, Float) -> Unit,
    onUpdateEffects: (AudioEffectsConfig) -> Unit,
    onUpdateMidiNote: (padIndex: Int, midiNote: Int) -> Unit,
    onExportBackupUri: (Uri) -> Unit,
    onInspectBackupUri: (Uri) -> Unit,
    onConfirmRestore: (RestoreMode) -> Unit,
    onDismissBackupPreview: () -> Unit,
    onImportExternalBackupUri: (Uri) -> Unit,
    onDismissExternalOutcome: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip"),
        onResult = { uri -> uri?.let(onExportBackupUri) }
    )
    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri -> uri?.let(onInspectBackupUri) }
    )
    val externalImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri -> uri?.let(onImportExternalBackupUri) }
    )

    val fx = uiState.effectsConfig
    val patch = uiState.currentPatch
    val padToNote = uiState.midiConfig.padToNoteMap()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ChassisBlack)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(RackSurface)
                .border(1.dp, BezelBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "OCTAPAD 20 PRO — SETTINGS & AUDIO RACK",
                    style = MaterialTheme.typography.titleLarge,
                    color = LedCyan
                )
                Text(
                    text = "Audio Engine • Effects • MIDI • Backup & Restore • Orientation",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
            if (uiState.statusBannerMessage != null) {
                Text(
                    text = uiState.statusBannerMessage,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (uiState.statusBannerIsError) LedRed else LedGreen,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = LedCyan, contentColor = ChassisBlack),
                modifier = Modifier.testTag("settings_back_button")
            ) {
                Text("BACK TO PADS", fontWeight = FontWeight.Bold)
            }
        }

        // Two-Column Landscape Settings Rack
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // LEFT COLUMN: Mixer (Master + 8 Pads) & Audio Effects
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 1. Master & Pad Mixer
                SettingsCard(title = "MASTER & PAD VOLUMES (${patch.codeLabel}: ${patch.name})") {
                    LabeledSliderRow(
                        label = "Master Volume",
                        valueText = "${(uiState.masterVolume * 100).roundToInt()}%",
                        value = uiState.masterVolume,
                        range = 0f..1f,
                        onValueChange = onMasterVolumeChange,
                        accent = LedCyan
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    patch.pads.forEach { pad ->
                        LabeledSliderRow(
                            label = "${pad.padLabel} (${pad.soundName})",
                            valueText = "${(pad.volume * 100).roundToInt()}%",
                            value = pad.volume,
                            range = 0f..1f,
                            onValueChange = { v -> onPadVolumeChange(pad.padIndex, v) },
                            accent = Color(pad.borderColorHex)
                        )
                    }
                }

                // 2. Audio Effects Rack
                SettingsCard(title = "AUDIO EFFECTS RACK") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (fx.effectsEnabled) "Effects Processing Active" else "Effects Bypassed (Lowest Latency)",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (fx.effectsEnabled) LedGreen else TextSecondary
                        )
                        Switch(
                            checked = fx.effectsEnabled,
                            onCheckedChange = { onUpdateEffects(fx.copy(effectsEnabled = it)) },
                            modifier = Modifier.testTag("effects_enable_switch")
                        )
                    }
                    LabeledSliderRow(
                        label = "Reverb",
                        valueText = "${(fx.reverbLevel * 100).roundToInt()}%",
                        value = fx.reverbLevel,
                        range = 0f..1f,
                        onValueChange = { onUpdateEffects(fx.copy(reverbLevel = it)) },
                        accent = LedAmber
                    )
                    LabeledSliderRow(
                        label = "Delay Echo",
                        valueText = "${(fx.delayLevel * 100).roundToInt()}%",
                        value = fx.delayLevel,
                        range = 0f..1f,
                        onValueChange = { onUpdateEffects(fx.copy(delayLevel = it)) },
                        accent = LedAmber
                    )
                    LabeledSliderRow(
                        label = "Bass",
                        valueText = "${(fx.bassBoost * 100).roundToInt()}%",
                        value = fx.bassBoost,
                        range = -1f..1f,
                        onValueChange = { onUpdateEffects(fx.copy(bassBoost = it)) },
                        accent = LedCyan
                    )
                    LabeledSliderRow(
                        label = "Mid",
                        valueText = "${(fx.midGain * 100).roundToInt()}%",
                        value = fx.midGain,
                        range = -1f..1f,
                        onValueChange = { onUpdateEffects(fx.copy(midGain = it)) },
                        accent = LedCyan
                    )
                    LabeledSliderRow(
                        label = "Treble",
                        valueText = "${(fx.trebleGain * 100).roundToInt()}%",
                        value = fx.trebleGain,
                        range = -1f..1f,
                        onValueChange = { onUpdateEffects(fx.copy(trebleGain = it)) },
                        accent = LedCyan
                    )
                }
            }

            // RIGHT COLUMN: Engine Status, MIDI, Backup & Restore, External Import, Orientation & Info
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 3. Audio Engine & Sample Status
                val audio = uiState.audioStatus
                SettingsCard(title = "AUDIO ENGINE & SAMPLE STATUS") {
                    StatusLine("Engine State", if (audio.isInitialized) "Active (Persistent SoundPool)" else "Initializing", if (audio.isInitialized) LedGreen else LedAmber)
                    StatusLine("Bundled Samples", "${audio.loadedBundledCount} / ${audio.totalBundledCount} Preloaded", LedCyan)
                    StatusLine("Custom Samples", "${uiState.customSamples.size} Imported (${audio.loadedCustomCount} Cached)", LedCyan)
                    StatusLine("Hardware Audio", "${audio.sampleRateHz} Hz • ${audio.framesPerBuffer} frames/buf", TextPrimary)
                    StatusLine("Audio Focus", if (audio.hasAudioFocus) "Granted" else "Standby (Auto-Recovers on Play)", TextSecondary)
                }

                // 4. USB MIDI Controller & Note Mapping
                val midi = uiState.midiStatus
                SettingsCard(title = "USB MIDI CONTROLLER & PAD MAPPING") {
                    StatusLine(
                        "Connection",
                        if (midi.isConnected) "Connected: ${midi.connectedDevices.joinToString()}" else "No MIDI Device Connected",
                        if (midi.isConnected) LedGreen else TextSecondary
                    )
                    if (midi.lastNote != null) {
                        StatusLine(
                            "Last MIDI Input",
                            "Note ${midi.lastNote}" + (midi.lastPadTriggered?.let { " -> PAD ${it + 1}" } ?: " (Unmapped)"),
                            LedAmber
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    for (padIdx in 0..7) {
                        val note = padToNote[padIdx] ?: (36 + padIdx)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("PAD ${padIdx + 1}", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { onUpdateMidiNote(padIdx, (note - 1).coerceAtLeast(0)) }
                                ) { Text("-") }
                                Text(
                                    text = "Note $note",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = LedCyan,
                                    modifier = Modifier.width(68.dp)
                                )
                                OutlinedButton(
                                    onClick = { onUpdateMidiNote(padIdx, (note + 1).coerceAtMost(127)) }
                                ) { Text("+") }
                            }
                        }
                    }
                }

                // 5. Backup & Restore + External Octapad Framework
                SettingsCard(title = "BACKUP, RESTORE & EXTERNAL IMPORT") {
                    Text(
                        text = "Versioned Backup (.zip) saves all 200 patches (Bank A & Bank B) and imported custom audio samples.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { exportBackupLauncher.launch("octapad20pro_backup_v1.zip") },
                            colors = ButtonDefaults.buttonColors(containerColor = LedGreen, contentColor = ChassisBlack),
                            modifier = Modifier.weight(1f).testTag("export_backup_button")
                        ) {
                            Text("EXPORT BACKUP")
                        }
                        OutlinedButton(
                            onClick = { importBackupLauncher.launch(arrayOf("application/zip", "*/*")) },
                            modifier = Modifier.weight(1f).testTag("restore_backup_button")
                        ) {
                            Text("RESTORE BACKUP")
                        }
                    }
                    OutlinedButton(
                        onClick = { externalImportLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxWidth().testTag("external_import_button")
                    ) {
                        Text("IMPORT EXTERNAL KIT (JSON / CSV / SPD INSPECTOR)")
                    }
                }

                // 6. Orientation & App Info
                SettingsCard(title = "ORIENTATION & APP INFORMATION") {
                    StatusLine("Screen Orientation", "Landscape Locked (sensorLandscape)", LedCyan)
                    StatusLine("Patch Capacity", "200 Independent Patches (100 Bank A + 100 Bank B)", TextPrimary)
                    StatusLine("Offline Storage", "Room SQLite + Local Custom Sample Vault", TextPrimary)
                    StatusLine("Application", "OCTAPAD 20 PRO v1.0", TextSecondary)
                }
            }
        }
    }

    uiState.pendingBackupPreview?.let { preview ->
        BackupRestoreConfirmDialog(
            preview = preview,
            onRestore = onConfirmRestore,
            onDismiss = onDismissBackupPreview
        )
    }

    uiState.externalImportOutcome?.let { outcome ->
        ExternalImportOutcomeDialog(
            outcome = outcome,
            onDismiss = onDismissExternalOutcome
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(RackSurface)
            .border(1.dp, BezelBorder, RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
            color = LedAmber
        )
        content()
    }
}

@Composable
private fun LabeledSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    accent: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(PanelSurface)
            .padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextPrimary,
            modifier = Modifier.weight(0.45f)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = ControlRaised
            ),
            modifier = Modifier
                .weight(0.42f)
                .height(26.dp)
        )
        Text(
            text = valueText,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            modifier = Modifier.weight(0.13f)
        )
    }
}

@Composable
private fun StatusLine(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(value, style = MaterialTheme.typography.labelMedium, color = valueColor)
    }
}
