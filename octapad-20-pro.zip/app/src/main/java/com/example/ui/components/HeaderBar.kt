package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Bank
import com.example.data.model.MidiStatus
import com.example.data.model.Patch
import com.example.ui.theme.BezelBorder
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ControlRaised
import com.example.ui.theme.LedAmber
import com.example.ui.theme.LedCyan
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.RackSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun HeaderBar(
    selectedBank: Bank,
    currentPatch: Patch,
    masterVolume: Float,
    midiStatus: MidiStatus,
    onSelectBank: (Bank) -> Unit,
    onToggleFavorite: () -> Unit,
    onSaveClick: () -> Unit,
    onLoadClick: () -> Unit,
    onEditClick: () -> Unit,
    onCopyClick: () -> Unit,
    onClearClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onMasterVolumeChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(RackSurface)
            .border(1.dp, BezelBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 1. Brand Plate & Real MIDI Status Indicator
        Column(
            modifier = Modifier.widthIn(min = 132.dp, max = 162.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "OCTAPAD 20 PRO",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                ),
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text(
                    text = "PROFESSIONAL MOBILE OCTAPAD",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 7.5.sp),
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            MidiStatusPill(midiStatus = midiStatus)
        }

        // 2. Bank A / Bank B Illuminated Selector
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BankToggleChip(
                label = "BANK A",
                selected = selectedBank == Bank.A,
                accentColor = LedCyan,
                testTag = "bank_a_button",
                onClick = { onSelectBank(Bank.A) }
            )
            BankToggleChip(
                label = "BANK B",
                selected = selectedBank == Bank.B,
                accentColor = LedAmber,
                testTag = "bank_b_button",
                onClick = { onSelectBank(Bank.B) }
            )
        }

        // 3. LCD Patch Readout (Current Patch Number + Name + Favorite Star)
        Row(
            modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(ChassisBlack)
                .border(1.dp, if (selectedBank == Bank.A) LedCyan.copy(alpha = 0.45f) else LedAmber.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(ControlRaised)
                    .padding(horizontal = 7.dp, vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${currentPatch.number}",
                    style = MaterialTheme.typography.titleSmall.copy(fontSize = 14.sp),
                    color = if (selectedBank == Bank.A) LedCyan else LedAmber,
                    modifier = Modifier.testTag("current_patch_number")
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = currentPatch.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp),
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.testTag("current_patch_name")
                )
                Text(
                    text = "${selectedBank.label} • PATCH ${currentPatch.number}",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp),
                    color = TextMuted,
                    maxLines = 1
                )
            }
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("favorite_toggle_button")
            ) {
                Icon(
                    imageVector = if (currentPatch.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                    contentDescription = if (currentPatch.isFavorite) "Remove patch from favorites" else "Add patch to favorites",
                    tint = if (currentPatch.isFavorite) LedAmber else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // 4. Patch Action Buttons: SAVE, LOAD, EDIT, COPY, CLEAR, SETTINGS
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RackActionButton("SAVE", LedGreen, "save_button", onSaveClick)
            RackActionButton("LOAD", LedCyan, "load_button", onLoadClick)
            RackActionButton("EDIT", LedAmber, "edit_button", onEditClick)
            RackActionButton("COPY", TextPrimary, "copy_button", onCopyClick)
            RackActionButton("CLEAR", LedRed, "clear_button", onClearClick)
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(ControlRaised)
                    .border(1.dp, BezelBorder, RoundedCornerShape(6.dp))
                    .clickable(onClick = onSettingsClick)
                    .testTag("settings_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = "Open Settings",
                    tint = TextPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // 5. Master Volume Control
        Row(
            modifier = Modifier
                .width(126.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(PanelSurface)
                .border(1.dp, BezelBorder, RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                contentDescription = "Master Volume",
                tint = LedCyan,
                modifier = Modifier.size(15.dp)
            )
            Column(modifier = Modifier.weight(1f).padding(start = 4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "VOL",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                        color = TextSecondary
                    )
                    Text(
                        text = "${(masterVolume * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                        color = LedCyan,
                        modifier = Modifier.testTag("master_volume_label")
                    )
                }
                Slider(
                    value = masterVolume,
                    onValueChange = onMasterVolumeChange,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = LedCyan,
                        activeTrackColor = LedCyan,
                        inactiveTrackColor = ControlRaised
                    ),
                    modifier = Modifier
                        .height(22.dp)
                        .testTag("master_volume_slider")
                )
            }
        }
    }
}

@Composable
private fun MidiStatusPill(midiStatus: MidiStatus) {
    val active = midiStatus.isConnected
    val dotColor = if (active) LedGreen else TextMuted
    val label = if (active) {
        midiStatus.connectedDevices.firstOrNull()?.take(14) ?: "MIDI ON"
    } else {
        "MIDI OFF"
    }
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(ChassisBlack)
            .border(1.dp, if (active) LedGreen.copy(alpha = 0.6f) else BezelBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp)
            .testTag("midi_status_indicator"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
            color = if (active) LedGreen else TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun BankToggleChip(
    label: String,
    selected: Boolean,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .height(40.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) accentColor.copy(alpha = 0.18f) else ControlRaised)
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) accentColor else BezelBorder,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
            color = if (selected) accentColor else TextSecondary,
            maxLines = 1
        )
    }
}

@Composable
private fun RackActionButton(
    label: String,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = ControlRaised,
            contentColor = accentColor
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.55f)),
        modifier = Modifier
            .height(40.dp)
            .testTag(testTag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge.copy(fontSize = 10.sp),
            maxLines = 1
        )
    }
}
