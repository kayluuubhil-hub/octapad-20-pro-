package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BundledSoundCatalog
import com.example.data.model.CustomSample
import com.example.data.model.PadConfig
import com.example.data.model.Patch
import com.example.ui.theme.BezelBorder
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ControlRaised
import com.example.ui.theme.LedAmber
import com.example.ui.theme.LedCyan
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.RackSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun PatchEditor(
    editingPatch: Patch,
    selectedPadIndex: Int,
    customSamples: List<CustomSample>,
    statusBannerMessage: String?,
    statusBannerIsError: Boolean,
    onSelectPad: (Int) -> Unit,
    onUpdatePatch: ((Patch) -> Patch) -> Unit,
    onPreviewSound: (soundId: String, customPath: String?, pitch: Float) -> Unit,
    onImportSampleUri: (Uri) -> Unit,
    onSave: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onCancel)

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                onImportSampleUri(uri)
            }
        }
    )

    val selectedPad = editingPatch.pads.getOrNull(selectedPadIndex) ?: editingPatch.pads.first()
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = remember {
        listOf("All", "Indian Folk", "Kick", "Snare", "Cymbal", "Tom", "Percussion", "Electronic", "Custom")
    }

    val filteredBundled = remember(selectedCategory) {
        when (selectedCategory) {
            "All" -> BundledSoundCatalog.sounds
            "Custom" -> emptyList()
            else -> BundledSoundCatalog.sounds.filter { it.category == selectedCategory }
        }
    }

    fun updateSelectedPad(transform: (PadConfig) -> PadConfig) {
        onUpdatePatch { patch ->
            patch.copy(
                pads = patch.pads.map { p ->
                    if (p.padIndex == selectedPadIndex) transform(p) else p
                }
            )
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ChassisBlack)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag("patch_editor_screen"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Editor Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(RackSurface)
                .border(1.dp, BezelBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column {
                Text(
                    text = "PATCH EDITOR",
                    style = MaterialTheme.typography.titleMedium,
                    color = LedAmber
                )
                Text(
                    text = "${editingPatch.bank.label} • PATCH ${editingPatch.number}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }

            OutlinedTextField(
                value = editingPatch.name,
                onValueChange = { newName ->
                    onUpdatePatch { it.copy(name = newName.take(28)) }
                },
                label = { Text("Patch Name") },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("patch_name_input")
            )

            if (statusBannerMessage != null) {
                Text(
                    text = statusBannerMessage,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (statusBannerIsError) LedRed else LedGreen,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(0.7f, fill = false)
                )
            }

            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.testTag("editor_cancel_button")
            ) {
                Text("CANCEL")
            }

            Button(
                onClick = onSave,
                colors = ButtonDefaults.buttonColors(containerColor = LedGreen, contentColor = ChassisBlack),
                modifier = Modifier.testTag("editor_save_button")
            ) {
                Text("SAVE PATCH", fontWeight = FontWeight.Bold)
            }
        }

        // Main Split Content: Left = 4x2 Pad Picker, Right = Selected Pad Inspector & Sound Bank
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Left Pane: 8 Pad Selector (4x2)
            Column(
                modifier = Modifier
                    .weight(0.42f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
                    .background(RackSurface)
                    .border(1.dp, BezelBorder, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "SELECT PAD TO EDIT",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                for (rowIdx in 0..1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (colIdx in 0..3) {
                            val padIdx = rowIdx * 4 + colIdx
                            val pad = editingPatch.pads[padIdx]
                            val isSelected = padIdx == selectedPadIndex
                            val padColor = Color(pad.borderColorHex)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) padColor.copy(alpha = 0.22f) else PanelSurface)
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.dp,
                                        color = if (isSelected) padColor else BezelBorder,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        onSelectPad(padIdx)
                                        onPreviewSound(pad.soundId, pad.customSamplePath, pad.pitch)
                                    }
                                    .padding(6.dp)
                                    .testTag("editor_pad_${padIdx + 1}"),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = pad.padLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = padColor
                                )
                                Text(
                                    text = pad.soundName,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = if (pad.enabled) TextPrimary else TextMuted,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (pad.enabled) "${(pad.volume * 100).roundToInt()}%" else "OFF",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // Right Pane: Pad Parameters + Sound Library + Custom Sample Import
            Column(
                modifier = Modifier
                    .weight(0.58f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
                    .background(RackSurface)
                    .border(1.dp, BezelBorder, RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Selected Pad Header + Preview + Enable Switch + Add Sample
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "${selectedPad.padLabel}: ${selectedPad.soundName}",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(selectedPad.borderColorHex)
                        )
                        Text(
                            text = if (selectedPad.isCustomSample) "Custom Audio Sample" else "Bundled Studio Sound",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                onPreviewSound(
                                    selectedPad.soundId,
                                    selectedPad.customSamplePath,
                                    selectedPad.pitch
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("preview_sample_button")
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Preview", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("PREVIEW")
                        }

                        Button(
                            onClick = {
                                audioPickerLauncher.launch(
                                    arrayOf("audio/wav", "audio/x-wav", "audio/mpeg", "audio/ogg", "audio/*")
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LedCyan, contentColor = ChassisBlack),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("add_sample_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "Add Custom Sample", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("ADD SAMPLE")
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("ON", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Switch(
                                checked = selectedPad.enabled,
                                onCheckedChange = { enabled ->
                                    updateSelectedPad { it.copy(enabled = enabled) }
                                },
                                modifier = Modifier.testTag("pad_enabled_switch")
                            )
                        }
                    }
                }

                // Pad Sliders: Volume, Pitch, Pan
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(PanelSurface)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ParameterSlider(
                        label = "VOLUME",
                        valueText = "${(selectedPad.volume * 100).roundToInt()}%",
                        value = selectedPad.volume,
                        range = 0f..1f,
                        onValueChange = { v -> updateSelectedPad { it.copy(volume = v) } },
                        modifier = Modifier.weight(1f).testTag("editor_pad_volume_slider")
                    )
                    ParameterSlider(
                        label = "PITCH",
                        valueText = String.format("%.2fx", selectedPad.pitch),
                        value = selectedPad.pitch,
                        range = 0.5f..2.0f,
                        onValueChange = { p -> updateSelectedPad { it.copy(pitch = p) } },
                        modifier = Modifier.weight(1f).testTag("editor_pad_pitch_slider")
                    )
                    ParameterSlider(
                        label = "PAN",
                        valueText = when {
                            selectedPad.pan < -0.05f -> "L${(-selectedPad.pan * 100).roundToInt()}"
                            selectedPad.pan > 0.05f -> "R${(selectedPad.pan * 100).roundToInt()}"
                            else -> "C"
                        },
                        value = selectedPad.pan,
                        range = -1f..1f,
                        onValueChange = { pan -> updateSelectedPad { it.copy(pan = pan) } },
                        modifier = Modifier.weight(1f).testTag("editor_pad_pan_slider")
                    )
                }

                // Category Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(categories) { cat ->
                        val active = cat == selectedCategory
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (active) LedCyan.copy(alpha = 0.22f) else ControlRaised)
                                .border(1.dp, if (active) LedCyan else BezelBorder, RoundedCornerShape(4.dp))
                                .clickable { selectedCategory = cat }
                                .padding(horizontal = 9.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = if (cat == "Custom") "Custom (${customSamples.size})" else cat,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) LedCyan else TextSecondary
                            )
                        }
                    }
                }

                // Sound Picker Grid (Bundled + Custom Samples)
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 118.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (selectedCategory == "All" || selectedCategory == "Custom") {
                        items(customSamples, key = { "custom_${it.sampleId}" }) { sample ->
                            val isAssigned = selectedPad.isCustomSample && selectedPad.soundId == sample.sampleId
                            SoundOptionCard(
                                title = sample.displayName,
                                subtitle = "CUSTOM",
                                isAssigned = isAssigned,
                                accent = LedAmber,
                                onClick = {
                                    updateSelectedPad {
                                        it.copy(
                                            soundId = sample.sampleId,
                                            soundName = sample.displayName,
                                            isCustomSample = true,
                                            customSamplePath = sample.filePath
                                        )
                                    }
                                    onPreviewSound(sample.sampleId, sample.filePath, selectedPad.pitch)
                                }
                            )
                        }
                    }

                    items(filteredBundled, key = { "bundled_${it.id}" }) { sound ->
                        val isAssigned = !selectedPad.isCustomSample && selectedPad.soundId == sound.id
                        SoundOptionCard(
                            title = sound.displayName,
                            subtitle = sound.category.uppercase(),
                            isAssigned = isAssigned,
                            accent = LedCyan,
                            onClick = {
                                updateSelectedPad {
                                    it.copy(
                                        soundId = sound.id,
                                        soundName = sound.displayName,
                                        isCustomSample = false,
                                        customSamplePath = null
                                    )
                                }
                                onPreviewSound(sound.id, null, selectedPad.pitch)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ParameterSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text(valueText, style = MaterialTheme.typography.labelSmall, color = LedCyan)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = LedCyan,
                activeTrackColor = LedCyan,
                inactiveTrackColor = ControlRaised
            ),
            modifier = Modifier.height(26.dp)
        )
    }
}

@Composable
private fun SoundOptionCard(
    title: String,
    subtitle: String,
    isAssigned: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isAssigned) accent.copy(alpha = 0.2f) else PanelSurface)
            .border(1.dp, if (isAssigned) accent else BezelBorder, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp),
            color = if (isAssigned) accent else TextMuted,
            maxLines = 1
        )
    }
}
