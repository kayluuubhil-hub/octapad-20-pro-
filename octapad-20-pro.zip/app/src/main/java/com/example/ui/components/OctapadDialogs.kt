package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.backup.BackupPreview
import com.example.backup.ExternalImportOutcome
import com.example.backup.RestoreMode
import com.example.data.model.Bank
import com.example.data.model.Patch
import com.example.ui.theme.BezelBorder
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ControlRaised
import com.example.ui.theme.LedAmber
import com.example.ui.theme.LedCyan
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.RackSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LoadPatchDialog(
    selectedBank: Bank,
    selectedPatchNumber: Int,
    bankAPatches: Map<Int, Patch>,
    bankBPatches: Map<Int, Patch>,
    onSelectPatch: (Bank, Int) -> Unit,
    onReloadCurrent: () -> Unit,
    onDismiss: () -> Unit
) {
    var activeTabBank by remember { mutableStateOf(selectedBank) }
    var favoritesOnly by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val sourceMap = if (activeTabBank == Bank.A) bankAPatches else bankBPatches
    val filtered = remember(activeTabBank, favoritesOnly, query, bankAPatches, bankBPatches) {
        (1..100).mapNotNull { num -> sourceMap[num] }
            .filter { p -> !favoritesOnly || p.isFavorite }
            .filter { p ->
                query.isBlank() ||
                    p.name.contains(query, ignoreCase = true) ||
                    p.number.toString() == query.trim()
            }
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .widthIn(min = 460.dp, max = 580.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(RackSurface)
                .border(1.dp, BezelBorder, RoundedCornerShape(12.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("LOAD PATCH", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = onReloadCurrent) {
                        Text("Reload Current (${selectedBank.id}-$selectedPatchNumber)")
                    }
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Bank.entries.forEach { bank ->
                    val active = bank == activeTabBank
                    OutlinedButton(
                        onClick = { activeTabBank = bank },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (active) LedCyan.copy(alpha = 0.2f) else ControlRaised,
                            contentColor = if (active) LedCyan else TextSecondary
                        )
                    ) {
                        Text(bank.label)
                    }
                }
                OutlinedButton(
                    onClick = { favoritesOnly = !favoritesOnly },
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (favoritesOnly) LedAmber.copy(alpha = 0.2f) else ControlRaised,
                        contentColor = if (favoritesOnly) LedAmber else TextSecondary
                    )
                ) {
                    Text(if (favoritesOnly) "★ Favorites" else "All 100")
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search name or #") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 140.dp, max = 210.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(filtered, key = { "${it.bank.id}-${it.number}" }) { patch ->
                    val isCurrent = patch.bank == selectedBank && patch.number == selectedPatchNumber
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isCurrent) LedCyan.copy(alpha = 0.14f) else ChassisBlack)
                            .border(1.dp, if (isCurrent) LedCyan else BezelBorder, RoundedCornerShape(6.dp))
                            .clickable { onSelectPatch(patch.bank, patch.number) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${patch.bank.id}-${patch.number}",
                                style = MaterialTheme.typography.titleSmall,
                                color = if (patch.bank == Bank.A) LedCyan else LedAmber
                            )
                            Text(
                                text = patch.name,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                        }
                        if (patch.isFavorite) {
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = "Favorite",
                                tint = LedAmber
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CopyPatchDialog(
    sourcePatch: Patch,
    bankAPatches: Map<Int, Patch>,
    bankBPatches: Map<Int, Patch>,
    onConfirmCopy: (Bank, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var targetBank by remember { mutableStateOf(sourcePatch.bank) }
    var targetNumber by remember {
        mutableIntStateOf(if (sourcePatch.number < 100) sourcePatch.number + 1 else 1)
    }

    val targetExistingName = (if (targetBank == Bank.A) bankAPatches else bankBPatches)[targetNumber]?.name
        ?: "Patch $targetNumber"

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .widthIn(min = 380.dp, max = 460.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(RackSurface)
                .border(1.dp, BezelBorder, RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("COPY PATCH", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
            Text(
                text = "Source: ${sourcePatch.codeLabel} — ${sourcePatch.name}",
                style = MaterialTheme.typography.bodyMedium,
                color = LedCyan
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Bank.entries.forEach { bank ->
                    val active = bank == targetBank
                    OutlinedButton(
                        onClick = { targetBank = bank },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (active) LedAmber.copy(alpha = 0.2f) else ControlRaised,
                            contentColor = if (active) LedAmber else TextSecondary
                        )
                    ) {
                        Text("Target ${bank.label}")
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Target Patch #:", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                OutlinedButton(onClick = { targetNumber = if (targetNumber > 1) targetNumber - 1 else 100 }) {
                    Text("-1")
                }
                Text(
                    text = "$targetNumber",
                    style = MaterialTheme.typography.titleLarge,
                    color = LedAmber,
                    modifier = Modifier.width(42.dp)
                )
                OutlinedButton(onClick = { targetNumber = if (targetNumber < 100) targetNumber + 1 else 1 }) {
                    Text("+1")
                }
                OutlinedButton(onClick = { targetNumber = ((targetNumber + 9) % 100) + 1 }) {
                    Text("+10")
                }
            }

            Text(
                text = "Destination currently holds: $targetExistingName",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = { onConfirmCopy(targetBank, targetNumber) },
                    colors = ButtonDefaults.buttonColors(containerColor = LedGreen, contentColor = ChassisBlack),
                    modifier = Modifier.testTag("confirm_copy_button")
                ) {
                    Text("Copy Patch")
                }
            }
        }
    }
}

@Composable
fun ClearPatchConfirmDialog(
    patch: Patch,
    onConfirmClear: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = RackSurface,
        title = { Text("Clear Selected Patch?", color = TextPrimary) },
        text = {
            Text(
                text = "This will reset ONLY ${patch.codeLabel} (${patch.name}) back to a clean default kit. All other 199 patches remain untouched.",
                color = TextSecondary
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirmClear,
                colors = ButtonDefaults.buttonColors(containerColor = LedRed, contentColor = TextPrimary),
                modifier = Modifier.testTag("confirm_clear_button")
            ) {
                Text("Clear Patch")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun BackupRestoreConfirmDialog(
    preview: BackupPreview,
    onRestore: (RestoreMode) -> Unit,
    onDismiss: () -> Unit
) {
    val dateStr = remember(preview.exportedAt) {
        if (preview.exportedAt > 0L) {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(preview.exportedAt))
        } else "Unknown date"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = RackSurface,
        title = { Text("Restore Octapad Backup (v${preview.formatVersion})", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Exported: $dateStr", color = TextSecondary)
                Text("Patches in backup: ${preview.patchCount}", color = TextPrimary)
                Text("Custom samples bundled: ${preview.customSampleCount}", color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Choose Merge to protect unchanged factory/local patches, or Replace All to overwrite all patches.",
                    style = MaterialTheme.typography.bodySmall,
                    color = LedAmber
                )
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onRestore(RestoreMode.MERGE_CUSTOM_ONLY) }) {
                    Text("Merge Newer")
                }
                Button(
                    onClick = { onRestore(RestoreMode.REPLACE_ALL) },
                    colors = ButtonDefaults.buttonColors(containerColor = LedCyan, contentColor = ChassisBlack)
                ) {
                    Text("Replace All")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ExternalImportOutcomeDialog(
    outcome: ExternalImportOutcome,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = RackSurface,
        title = {
            Text(
                text = when (outcome) {
                    is ExternalImportOutcome.Imported -> "External Kit Imported"
                    is ExternalImportOutcome.Unsupported -> "Unsupported External Format"
                },
                color = if (outcome is ExternalImportOutcome.Imported) LedGreen else LedAmber
            )
        },
        text = {
            when (outcome) {
                is ExternalImportOutcome.Imported -> {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Format: ${outcome.sourceFormat}", color = TextPrimary)
                        Text("Patch: ${outcome.patch.name}", color = LedCyan)
                        Text(outcome.notes, color = TextSecondary)
                    }
                }
                is ExternalImportOutcome.Unsupported -> {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Detected: ${outcome.detectedModelOrFormat}", color = TextPrimary)
                        Text(outcome.technicalReason, color = TextSecondary)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("OK") }
        }
    )
}
