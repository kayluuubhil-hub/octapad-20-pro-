package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Bank
import com.example.data.model.Patch
import com.example.ui.theme.BezelBorder
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ControlRaised
import com.example.ui.theme.LedAmber
import com.example.ui.theme.LedCyan
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PatchNumberBar(
    selectedBank: Bank,
    selectedPatchNumber: Int,
    patchesMap: Map<Int, Patch>,
    showFavoritesOnly: Boolean,
    onSelectPatch: (Int) -> Unit,
    onToggleFavoritesFilter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = if (selectedBank == Bank.A) LedCyan else LedAmber
    val patchNumbers = if (showFavoritesOnly) {
        val favNums = (1..100).filter { num -> patchesMap[num]?.isFavorite == true }
        favNums.ifEmpty { listOf(selectedPatchNumber) }
    } else {
        (1..100).toList()
    }

    val listState = rememberLazyListState()

    LaunchedEffect(selectedPatchNumber, selectedBank, showFavoritesOnly) {
        val idx = patchNumbers.indexOf(selectedPatchNumber)
        if (idx >= 0) {
            listState.animateScrollToItem((idx - 4).coerceAtLeast(0))
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(38.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(PanelSurface)
            .border(1.dp, BezelBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        // Favorites Filter Toggle
        Row(
            modifier = Modifier
                .height(28.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(if (showFavoritesOnly) LedAmber.copy(alpha = 0.2f) else ControlRaised)
                .border(1.dp, if (showFavoritesOnly) LedAmber else BezelBorder, RoundedCornerShape(4.dp))
                .clickable(onClick = onToggleFavoritesFilter)
                .padding(horizontal = 7.dp)
                .testTag("favorites_filter_chip"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = "Filter Favorites",
                tint = if (showFavoritesOnly) LedAmber else TextSecondary,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = "FAV",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = if (showFavoritesOnly) LedAmber else TextSecondary
            )
        }

        // Previous Patch Step
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(ControlRaised)
                .border(1.dp, BezelBorder, RoundedCornerShape(4.dp))
                .clickable {
                    val prev = if (selectedPatchNumber > 1) selectedPatchNumber - 1 else 100
                    onSelectPatch(prev)
                }
                .testTag("patch_prev_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = "Previous Patch",
                tint = TextPrimary,
                modifier = Modifier.size(18.dp)
            )
        }

        // Horizontal Scrollable Patch Numbers 1..100
        LazyRow(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .testTag("patch_number_list"),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(patchNumbers, key = { it }) { number ->
                val isSelected = number == selectedPatchNumber
                val isFav = patchesMap[number]?.isFavorite == true
                Box(
                    modifier = Modifier
                        .widthIn(min = 32.dp)
                        .height(28.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            if (isSelected) accent else ChassisBlack
                        )
                        .border(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) accent else BezelBorder,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .clickable { onSelectPatch(number) }
                        .padding(horizontal = 6.dp)
                        .testTag("patch_chip_$number"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "$number",
                            style = MaterialTheme.typography.titleSmall.copy(fontSize = 12.sp),
                            color = if (isSelected) ChassisBlack else TextPrimary
                        )
                        if (isFav && !isSelected) {
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .clip(CircleShape)
                                    .background(LedAmber)
                            )
                        }
                    }
                }
            }
        }

        // Next Patch Step
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(ControlRaised)
                .border(1.dp, BezelBorder, RoundedCornerShape(4.dp))
                .clickable {
                    val next = if (selectedPatchNumber < 100) selectedPatchNumber + 1 else 1
                    onSelectPatch(next)
                }
                .testTag("patch_next_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Next Patch",
                tint = TextPrimary,
                modifier = Modifier.size(18.dp)
            )
        }

        Text(
            text = "${selectedBank.id}:$selectedPatchNumber/100",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = TextMuted
        )
    }
}
