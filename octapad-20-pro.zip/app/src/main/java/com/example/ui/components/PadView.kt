package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.changedToDownIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PadConfig
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.flow.StateFlow

@Composable
fun PadView(
    pad: PadConfig,
    hitPulseFlow: StateFlow<Long>,
    onTrigger: (padIndex: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = Color(pad.borderColorHex)
    val hitTimestamp by hitPulseFlow.collectAsStateWithLifecycle()
    val flashAlpha = remember { Animatable(0f) }

    LaunchedEffect(hitTimestamp) {
        if (hitTimestamp > 0L) {
            flashAlpha.snapTo(1.0f)
            flashAlpha.animateTo(0f, animationSpec = tween(durationMillis = 120))
        }
    }

    val shape = RoundedCornerShape(10.dp)
    val padSurface = if (pad.enabled) PanelSurface else ChassisBlack

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        padSurface.copy(alpha = 0.96f),
                        ChassisBlack
                    )
                )
            )
            .drawBehind {
                val glow = flashAlpha.value
                // Outer colored neon glow border
                drawRoundRect(
                    color = borderColor.copy(alpha = if (pad.enabled) (0.28f + glow * 0.65f) else 0.12f),
                    cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx()),
                    style = Stroke(width = (4.dp + (glow * 4f).dp).toPx())
                )
                // Inner flash illumination on hit
                if (glow > 0.01f && pad.enabled) {
                    drawRoundRect(
                        color = borderColor.copy(alpha = glow * 0.42f),
                        cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                    )
                }
            }
            .border(
                width = 2.dp,
                color = if (pad.enabled) borderColor else TextMuted.copy(alpha = 0.4f),
                shape = shape
            )
            .pointerInput(pad.padIndex, pad.enabled) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        event.changes.forEach { change ->
                            if (change.changedToDownIgnoreConsumed()) {
                                change.consume()
                                if (pad.enabled) {
                                    onTrigger(pad.padIndex)
                                }
                            }
                        }
                    }
                }
            }
            .semantics {
                role = Role.Button
                contentDescription = "${pad.padLabel}, ${pad.soundName}"
                onClick {
                    if (pad.enabled) {
                        onTrigger(pad.padIndex)
                    }
                    true
                }
            }
            .padding(10.dp)
            .testTag("pad_${pad.padIndex + 1}")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Row: PAD 1..PAD 8 badge + clean volume bar (no pencil icon, no red edit marks)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(borderColor.copy(alpha = if (pad.enabled) 0.18f else 0.08f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = pad.padLabel,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = if (pad.enabled) borderColor else TextMuted
                    )
                }

                if (!pad.enabled) {
                    Text(
                        text = "MUTED",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                        color = TextMuted
                    )
                } else {
                    // Subtle hardware volume level meter bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.32f)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(ChassisBlack)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(pad.volume.coerceIn(0.05f, 1f))
                                .fillMaxHeight()
                                .background(borderColor.copy(alpha = 0.75f))
                        )
                    }
                }
            }

            // Bottom/Center: Sound Name cleanly aligned
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = pad.soundName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (pad.enabled) TextPrimary else TextMuted,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.testTag("pad_${pad.padIndex + 1}_sound")
                )
            }
        }
    }
}
