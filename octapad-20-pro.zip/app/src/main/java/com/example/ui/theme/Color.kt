package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hardware Drum-Machine Obsidian & Graphite Surfaces
val ChassisBlack = Color(0xFF07080C)
val RackSurface = Color(0xFF10131A)
val PanelSurface = Color(0xFF161A24)
val ControlRaised = Color(0xFF202533)
val BezelBorder = Color(0xFF2D3345)
val BezelHighlight = Color(0xFF3F475E)

// Typography & Status Colors
val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFFA0AAC0)
val TextMuted = Color(0xFF6B748A)

// Hardware Indicator LEDs & Accents
val LedCyan = Color(0xFF00E5FF)
val LedAmber = Color(0xFFFFAB00)
val LedGreen = Color(0xFF00E676)
val LedRed = Color(0xFFFF3D57)
val LedBlue = Color(0xFF2979FF)
val LedMagenta = Color(0xFFFF2E93)
val LedViolet = Color(0xFFB388FF)
val LedLime = Color(0xFFC6FF00)

// Default 8-Pad Glowing Border Palette (4x2 layout)
val DefaultPadColors: List<Long> = listOf(
    0xFF00E5FFL, // Pad 1 - Electric Cyan
    0xFF00E676L, // Pad 2 - Neon Emerald
    0xFFFFAB00L, // Pad 3 - Amber Gold
    0xFFFF2E93L, // Pad 4 - Neon Magenta
    0xFF2979FFL, // Pad 5 - Cobalt Blue
    0xFFFF5252L, // Pad 6 - Crimson Coral
    0xFFB388FFL, // Pad 7 - Electric Violet
    0xFFC6FF00L  // Pad 8 - Acid Lime
)
