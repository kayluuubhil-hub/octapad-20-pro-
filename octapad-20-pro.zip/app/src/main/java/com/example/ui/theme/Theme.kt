package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val OctapadDarkColorScheme = darkColorScheme(
    primary = LedCyan,
    onPrimary = ChassisBlack,
    primaryContainer = ControlRaised,
    onPrimaryContainer = LedCyan,
    secondary = LedAmber,
    onSecondary = ChassisBlack,
    secondaryContainer = ControlRaised,
    onSecondaryContainer = LedAmber,
    tertiary = LedGreen,
    onTertiary = ChassisBlack,
    background = ChassisBlack,
    onBackground = TextPrimary,
    surface = RackSurface,
    onSurface = TextPrimary,
    surfaceVariant = PanelSurface,
    onSurfaceVariant = TextSecondary,
    outline = BezelBorder,
    outlineVariant = BezelHighlight,
    error = LedRed,
    onError = TextPrimary
)

@Composable
fun OctapadTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = OctapadDarkColorScheme,
        typography = OctapadTypography,
        content = content
    )
}
