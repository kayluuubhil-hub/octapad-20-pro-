package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.Bank
import com.example.ui.components.ClearPatchConfirmDialog
import com.example.ui.components.CopyPatchDialog
import com.example.ui.components.HeaderBar
import com.example.ui.components.LoadPatchDialog
import com.example.ui.components.PadView
import com.example.ui.components.PatchNumberBar
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.RackSurface
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.OctapadUiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow

@Composable
fun OctapadScreen(
    uiState: OctapadUiState,
    padHitPulseFlows: List<StateFlow<Long>>,
    onTriggerPad: (Int) -> Unit,
    onSelectBank: (Bank) -> Unit,
    onSelectPatch: (Int) -> Unit,
    onSelectBankAndPatch: (Bank, Int) -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleFavoritesFilter: () -> Unit,
    onSavePatch: () -> Unit,
    onShowLoadDialog: (Boolean) -> Unit,
    onReloadCurrentPatch: () -> Unit,
    onOpenEditor: () -> Unit,
    onShowCopyDialog: (Boolean) -> Unit,
    onConfirmCopyPatch: (Bank, Int) -> Unit,
    onShowClearDialog: (Boolean) -> Unit,
    onConfirmClearPatch: () -> Unit,
    onOpenSettings: () -> Unit,
    onMasterVolumeChange: (Float) -> Unit,
    onClearBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentPatch = uiState.currentPatch

    LaunchedEffect(uiState.statusBannerMessage) {
        if (uiState.statusBannerMessage != null) {
            delay(2800)
            onClearBanner()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ChassisBlack)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag("octapad_main_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            HeaderBar(
                selectedBank = uiState.selectedBank,
                currentPatch = currentPatch,
                masterVolume = uiState.masterVolume,
                midiStatus = uiState.midiStatus,
                onSelectBank = onSelectBank,
                onToggleFavorite = onToggleFavorite,
                onSaveClick = onSavePatch,
                onLoadClick = { onShowLoadDialog(true) },
                onEditClick = onOpenEditor,
                onCopyClick = { onShowCopyDialog(true) },
                onClearClick = { onShowClearDialog(true) },
                onSettingsClick = onOpenSettings,
                onMasterVolumeChange = onMasterVolumeChange
            )

            PatchNumberBar(
                selectedBank = uiState.selectedBank,
                selectedPatchNumber = uiState.selectedPatchNumber,
                patchesMap = uiState.activeBankPatches,
                showFavoritesOnly = uiState.showFavoritesOnlyInBar,
                onSelectPatch = onSelectPatch,
                onToggleFavoritesFilter = onToggleFavoritesFilter
            )

            // 4 Columns x 2 Rows = Exactly 8 Large Performance Pads
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("pads_grid"),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val pads = currentPatch.pads
                // Top Row: PAD 1, PAD 2, PAD 3, PAD 4
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (col in 0..3) {
                        val pad = pads.getOrNull(col)
                        if (pad != null) {
                            PadView(
                                pad = pad,
                                hitPulseFlow = padHitPulseFlows[col],
                                onTrigger = onTriggerPad,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            )
                        }
                    }
                }
                // Bottom Row: PAD 5, PAD 6, PAD 7, PAD 8
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (col in 4..7) {
                        val pad = pads.getOrNull(col)
                        if (pad != null) {
                            PadView(
                                pad = pad,
                                hitPulseFlow = padHitPulseFlows[col],
                                onTrigger = onTriggerPad,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            )
                        }
                    }
                }
            }
        }

        // Transient Feedback Toast Banner (non-blocking at bottom center)
        AnimatedVisibility(
            visible = uiState.statusBannerMessage != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
        ) {
            val isErr = uiState.statusBannerIsError
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(RackSurface.copy(alpha = 0.95f))
                    .border(
                        1.5.dp,
                        if (isErr) LedRed else LedGreen,
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("status_banner")
            ) {
                Text(
                    text = uiState.statusBannerMessage.orEmpty(),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isErr) LedRed else TextPrimary
                )
            }
        }
    }

    if (uiState.showLoadDialog) {
        LoadPatchDialog(
            selectedBank = uiState.selectedBank,
            selectedPatchNumber = uiState.selectedPatchNumber,
            bankAPatches = uiState.bankAPatches,
            bankBPatches = uiState.bankBPatches,
            onSelectPatch = onSelectBankAndPatch,
            onReloadCurrent = onReloadCurrentPatch,
            onDismiss = { onShowLoadDialog(false) }
        )
    }

    if (uiState.showCopyDialog) {
        CopyPatchDialog(
            sourcePatch = currentPatch,
            bankAPatches = uiState.bankAPatches,
            bankBPatches = uiState.bankBPatches,
            onConfirmCopy = onConfirmCopyPatch,
            onDismiss = { onShowCopyDialog(false) }
        )
    }

    if (uiState.showClearConfirmDialog) {
        ClearPatchConfirmDialog(
            patch = currentPatch,
            onConfirmClear = onConfirmClearPatch,
            onDismiss = { onShowClearDialog(false) }
        )
    }
}
