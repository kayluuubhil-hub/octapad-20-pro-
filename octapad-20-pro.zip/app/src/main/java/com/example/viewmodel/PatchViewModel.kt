package com.example.viewmodel

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioEngine
import com.example.backup.BackupManager
import com.example.backup.BackupPreview
import com.example.backup.ExternalBackupImporter
import com.example.backup.ExternalImportOutcome
import com.example.backup.RestoreMode
import com.example.data.PatchRepository
import com.example.data.PreferencesManager
import com.example.data.db.OctapadDatabase
import com.example.data.db.PresetPatchSeeder
import com.example.data.model.AppRoute
import com.example.data.model.AudioEffectsConfig
import com.example.data.model.AudioEngineStatus
import com.example.data.model.Bank
import com.example.data.model.CustomSample
import com.example.data.model.MidiConfig
import com.example.data.model.MidiStatus
import com.example.data.model.Patch
import com.example.midi.MidiManager
import com.example.sample.SampleImporter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OctapadUiState(
    val isReady: Boolean = false,
    val currentRoute: AppRoute = AppRoute.PLAY,
    val selectedBank: Bank = Bank.A,
    val selectedPatchNumber: Int = 1,
    val bankAPatches: Map<Int, Patch> = emptyMap(),
    val bankBPatches: Map<Int, Patch> = emptyMap(),
    val favoritePatches: List<Patch> = emptyList(),
    val customSamples: List<CustomSample> = emptyList(),
    val masterVolume: Float = 0.90f,
    val effectsConfig: AudioEffectsConfig = AudioEffectsConfig(),
    val midiConfig: MidiConfig = MidiConfig(),
    val midiStatus: MidiStatus = MidiStatus(),
    val audioStatus: AudioEngineStatus = AudioEngineStatus(),
    val editingPatch: Patch? = null,
    val editingPadIndex: Int = 0,
    val showFavoritesOnlyInBar: Boolean = false,
    val showLoadDialog: Boolean = false,
    val showCopyDialog: Boolean = false,
    val showClearConfirmDialog: Boolean = false,
    val pendingBackupPreview: BackupPreview? = null,
    val externalImportOutcome: ExternalImportOutcome? = null,
    val statusBannerMessage: String? = null,
    val statusBannerIsError: Boolean = false
) {
    val activeBankPatches: Map<Int, Patch>
        get() = if (selectedBank == Bank.A) bankAPatches else bankBPatches

    val currentPatch: Patch
        get() = activeBankPatches[selectedPatchNumber]
            ?: Patch(
                bank = selectedBank,
                number = selectedPatchNumber,
                name = "Patch $selectedPatchNumber",
                pads = PresetPatchSeeder.defaultCleanPads()
            )
}

class PatchViewModel(application: Application) : AndroidViewModel(application) {

    private val database = OctapadDatabase.getInstance(application)
    private val repository = PatchRepository(database.patchDao())
    private val preferencesManager = PreferencesManager(application)
    val audioEngine = AudioEngine(application)
    private val sampleImporter = SampleImporter(application, audioEngine)
    private val backupManager = BackupManager(application, repository)
    private val externalBackupImporter = ExternalBackupImporter(application)

    private val _uiState = MutableStateFlow(OctapadUiState())
    val uiState: StateFlow<OctapadUiState> = _uiState.asStateFlow()

    // Per-pad hit timestamps so tapping a single pad only updates that pad's visual flash
    // without recomposing HeaderBar, PatchNumberBar, or the other 7 pads.
    val padHitPulseFlows: List<MutableStateFlow<Long>> = List(8) { MutableStateFlow(0L) }

    @Volatile
    private var activePatchCache: Patch? = null

    private val midiManager = MidiManager(application) { padIndex, velocity, _ ->
        val patch = activePatchCache ?: return@MidiManager
        val pad = patch.pads.getOrNull(padIndex) ?: return@MidiManager
        val streamId = audioEngine.playPad(pad, velocity)
        if (streamId > 0 || pad.enabled) {
            padHitPulseFlows[padIndex].value = SystemClock.elapsedRealtime()
        }
    }

    init {
        initializeInstrument()
    }

    private fun initializeInstrument() {
        audioEngine.initializeAudio()
        midiManager.start()

        viewModelScope.launch {
            repository.ensureSeeded()
            val customSamples = repository.getAllCustomSamples()
            audioEngine.preloadSamples(customSamples)

            val initialPrefs = preferencesManager.preferencesFlow.first()
            audioEngine.setMasterVolume(initialPrefs.masterVolume)
            audioEngine.setEffectsConfig(initialPrefs.effects)
            midiManager.updateConfig(initialPrefs.midiConfig)

            _uiState.update {
                it.copy(
                    isReady = true,
                    selectedBank = initialPrefs.selectedBank,
                    selectedPatchNumber = initialPrefs.selectedPatchNumber,
                    masterVolume = initialPrefs.masterVolume,
                    effectsConfig = initialPrefs.effects,
                    midiConfig = initialPrefs.midiConfig
                )
            }
        }

        viewModelScope.launch {
            repository.observeBankPatches(Bank.A).collect { mapA ->
                _uiState.update { state ->
                    val next = state.copy(bankAPatches = mapA)
                    if (next.selectedBank == Bank.A) {
                        syncActivePatchCache(next.currentPatch)
                    }
                    next
                }
            }
        }

        viewModelScope.launch {
            repository.observeBankPatches(Bank.B).collect { mapB ->
                _uiState.update { state ->
                    val next = state.copy(bankBPatches = mapB)
                    if (next.selectedBank == Bank.B) {
                        syncActivePatchCache(next.currentPatch)
                    }
                    next
                }
            }
        }

        viewModelScope.launch {
            repository.observeFavorites().collect { favs ->
                _uiState.update { it.copy(favoritePatches = favs) }
            }
        }

        viewModelScope.launch {
            repository.observeCustomSamples().collect { samples ->
                _uiState.update { it.copy(customSamples = samples) }
            }
        }

        viewModelScope.launch {
            midiManager.midiStatus.collect { midi ->
                _uiState.update { it.copy(midiStatus = midi) }
            }
        }

        viewModelScope.launch {
            audioEngine.status.collect { status ->
                _uiState.update { it.copy(audioStatus = status) }
            }
        }

        viewModelScope.launch {
            audioEngine.soundPoolManager.loadedCountFlow.collect {
                audioEngine.refreshStatus()
            }
        }
    }

    private fun syncActivePatchCache(patch: Patch) {
        activePatchCache = patch
        audioEngine.syncPatchPadVolumes(patch.pads)
    }

    /**
     * Direct touch-event playback: synchronous, zero DB calls, zero coroutines.
     */
    fun triggerPad(padIndex: Int, velocity: Float = 1.0f) {
        if (padIndex !in 0..7) return
        val patch = activePatchCache ?: _uiState.value.currentPatch
        val pad = patch.pads.getOrNull(padIndex) ?: return
        if (!pad.enabled) return
        audioEngine.playPad(pad, velocity)
        padHitPulseFlows[padIndex].value = SystemClock.elapsedRealtime()
    }

    fun selectBank(bank: Bank) {
        _uiState.update { state ->
            val next = state.copy(selectedBank = bank)
            syncActivePatchCache(next.currentPatch)
            next
        }
        viewModelScope.launch {
            preferencesManager.setSelectedBankAndPatch(bank, _uiState.value.selectedPatchNumber)
        }
    }

    fun selectPatch(patchNumber: Int) {
        val clamped = patchNumber.coerceIn(1, 100)
        _uiState.update { state ->
            val next = state.copy(selectedPatchNumber = clamped)
            syncActivePatchCache(next.currentPatch)
            next
        }
        viewModelScope.launch {
            preferencesManager.setSelectedBankAndPatch(_uiState.value.selectedBank, clamped)
        }
    }

    fun selectBankAndPatch(bank: Bank, patchNumber: Int) {
        val clamped = patchNumber.coerceIn(1, 100)
        _uiState.update { state ->
            val next = state.copy(
                selectedBank = bank,
                selectedPatchNumber = clamped,
                showLoadDialog = false
            )
            syncActivePatchCache(next.currentPatch)
            next
        }
        viewModelScope.launch {
            preferencesManager.setSelectedBankAndPatch(bank, clamped)
        }
    }

    fun saveCurrentPatch() {
        val patch = _uiState.value.currentPatch
        viewModelScope.launch {
            repository.savePatch(patch)
            showBanner("Saved ${patch.codeLabel}: ${patch.name}")
        }
    }

    fun reloadCurrentPatchFromStorage() {
        val bank = _uiState.value.selectedBank
        val num = _uiState.value.selectedPatchNumber
        viewModelScope.launch {
            val loaded = repository.getPatch(bank, num)
            if (loaded != null) {
                syncActivePatchCache(loaded)
                _uiState.update { it.copy(showLoadDialog = false) }
                showBanner("Loaded ${loaded.codeLabel}: ${loaded.name}")
            }
        }
    }

    fun toggleCurrentPatchFavorite() {
        val patch = _uiState.value.currentPatch
        val nextFav = !patch.isFavorite
        viewModelScope.launch {
            repository.toggleFavorite(patch.bank, patch.number, nextFav)
            showBanner(
                if (nextFav) "Added ${patch.codeLabel} to Favorites"
                else "Removed ${patch.codeLabel} from Favorites"
            )
        }
    }

    fun toggleFavoriteFilterInBar() {
        _uiState.update { it.copy(showFavoritesOnlyInBar = !it.showFavoritesOnlyInBar) }
    }

    fun setMasterVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        audioEngine.setMasterVolume(clamped)
        _uiState.update { it.copy(masterVolume = clamped) }
        viewModelScope.launch {
            preferencesManager.setMasterVolume(clamped)
        }
    }

    fun setIndividualPadVolume(padIndex: Int, volume: Float) {
        if (padIndex !in 0..7) return
        val clamped = volume.coerceIn(0f, 1f)
        audioEngine.setPadVolume(padIndex, clamped)
        val patch = _uiState.value.currentPatch
        val updatedPads = patch.pads.map { p ->
            if (p.padIndex == padIndex) p.copy(volume = clamped) else p
        }
        val updatedPatch = patch.copy(pads = updatedPads)
        syncActivePatchCache(updatedPatch)
        viewModelScope.launch {
            repository.savePatch(updatedPatch)
        }
    }

    fun updateEffectsConfig(config: AudioEffectsConfig) {
        audioEngine.setEffectsConfig(config)
        _uiState.update { it.copy(effectsConfig = config) }
        viewModelScope.launch {
            preferencesManager.setEffectsConfig(config)
        }
    }

    fun updateMidiNoteForPad(padIndex: Int, midiNote: Int) {
        if (padIndex !in 0..7 || midiNote !in 0..127) return
        val currentMap = _uiState.value.midiConfig.noteToPad.toMutableMap()
        // Remove previous note pointing to this pad
        val existingNotesForPad = currentMap.filterValues { it == padIndex }.keys
        existingNotesForPad.forEach { currentMap.remove(it) }
        currentMap[midiNote] = padIndex
        val nextConfig = MidiConfig(currentMap)
        midiManager.updateConfig(nextConfig)
        _uiState.update { it.copy(midiConfig = nextConfig) }
        viewModelScope.launch {
            preferencesManager.setMidiMapping(currentMap)
        }
    }

    // Navigation & Dialog Controls
    fun openPatchEditor(initialPadIndex: Int = 0) {
        val current = _uiState.value.currentPatch
        _uiState.update {
            it.copy(
                currentRoute = AppRoute.PATCH_EDITOR,
                editingPatch = current.copy(pads = current.pads.map { p -> p.copy() }),
                editingPadIndex = initialPadIndex.coerceIn(0, 7)
            )
        }
    }

    fun selectEditingPad(padIndex: Int) {
        _uiState.update { it.copy(editingPadIndex = padIndex.coerceIn(0, 7)) }
    }

    fun updateEditingPatch(transform: (Patch) -> Patch) {
        _uiState.update { state ->
            val current = state.editingPatch ?: return@update state
            state.copy(editingPatch = transform(current))
        }
    }

    fun previewSound(soundId: String, customPath: String? = null, pitch: Float = 1.0f) {
        audioEngine.previewSample(soundId, customPath, pitch)
    }

    fun saveEditingPatch() {
        val edited = _uiState.value.editingPatch ?: return
        val cleanName = edited.name.trim().ifBlank { "Patch ${edited.number}" }
        val finalPatch = edited.copy(name = cleanName)
        viewModelScope.launch {
            repository.savePatch(finalPatch)
            syncActivePatchCache(finalPatch)
            _uiState.update {
                it.copy(
                    currentRoute = AppRoute.PLAY,
                    editingPatch = null
                )
            }
            showBanner("Saved ${finalPatch.codeLabel}: ${finalPatch.name}")
        }
    }

    fun cancelPatchEditor() {
        _uiState.update {
            it.copy(
                currentRoute = AppRoute.PLAY,
                editingPatch = null
            )
        }
    }

    fun openSettings() {
        audioEngine.refreshStatus()
        _uiState.update { it.copy(currentRoute = AppRoute.SETTINGS) }
    }

    fun closeSettings() {
        _uiState.update { it.copy(currentRoute = AppRoute.PLAY) }
    }

    fun setShowLoadDialog(show: Boolean) {
        _uiState.update { it.copy(showLoadDialog = show) }
    }

    fun setShowCopyDialog(show: Boolean) {
        _uiState.update { it.copy(showCopyDialog = show) }
    }

    fun copyCurrentPatchTo(targetBank: Bank, targetNumber: Int) {
        val srcBank = _uiState.value.selectedBank
        val srcNumber = _uiState.value.selectedPatchNumber
        viewModelScope.launch {
            val copied = repository.copyPatch(srcBank, srcNumber, targetBank, targetNumber)
            _uiState.update { it.copy(showCopyDialog = false) }
            if (copied != null) {
                showBanner("Copied ${srcBank.id}-$srcNumber to ${targetBank.id}-$targetNumber")
            } else {
                showBanner("Failed to copy patch.", isError = true)
            }
        }
    }

    fun setShowClearConfirmDialog(show: Boolean) {
        _uiState.update { it.copy(showClearConfirmDialog = show) }
    }

    fun confirmClearCurrentPatch() {
        val bank = _uiState.value.selectedBank
        val num = _uiState.value.selectedPatchNumber
        viewModelScope.launch {
            val cleared = repository.clearPatch(bank, num)
            syncActivePatchCache(cleared)
            _uiState.update { it.copy(showClearConfirmDialog = false) }
            showBanner("Cleared ${cleared.codeLabel} to default template")
        }
    }

    // Custom Sample Import
    fun importSampleFromUri(uri: Uri, assignToEditingPad: Boolean = true) {
        viewModelScope.launch {
            val result = sampleImporter.importFromUri(uri)
            result.onSuccess { sample ->
                repository.addCustomSample(sample)
                if (assignToEditingPad && _uiState.value.editingPatch != null) {
                    val padIdx = _uiState.value.editingPadIndex
                    updateEditingPatch { patch ->
                        patch.copy(
                            pads = patch.pads.map { pad ->
                                if (pad.padIndex == padIdx) {
                                    pad.copy(
                                        soundId = sample.sampleId,
                                        soundName = sample.displayName,
                                        isCustomSample = true,
                                        customSamplePath = sample.filePath
                                    )
                                } else pad
                            }
                        )
                    }
                }
                audioEngine.previewSample(sample.sampleId, sample.filePath, 1.0f)
                showBanner("Imported sample '${sample.displayName}'")
            }.onFailure { err ->
                showBanner(err.message ?: "Sample import failed.", isError = true)
            }
        }
    }

    // Backup & Restore
    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            val res = backupManager.exportBackupToUri(uri, _uiState.value.effectsConfig)
            res.onSuccess { msg -> showBanner(msg) }
                .onFailure { err -> showBanner(err.message ?: "Backup export failed", isError = true) }
        }
    }

    fun inspectBackupForRestore(uri: Uri) {
        viewModelScope.launch {
            val res = backupManager.inspectBackupFromUri(uri)
            res.onSuccess { preview ->
                _uiState.update { it.copy(pendingBackupPreview = preview) }
            }.onFailure { err ->
                showBanner(err.message ?: "Invalid backup archive", isError = true)
            }
        }
    }

    fun confirmBackupRestore(mode: RestoreMode) {
        val preview = _uiState.value.pendingBackupPreview ?: return
        viewModelScope.launch {
            val res = backupManager.applyBackupPreview(preview, mode)
            preview.effectsConfig?.let { fx ->
                if (mode == RestoreMode.REPLACE_ALL) {
                    updateEffectsConfig(fx)
                }
            }
            val customSamples = repository.getAllCustomSamples()
            audioEngine.preloadSamples(customSamples)
            _uiState.update { it.copy(pendingBackupPreview = null) }
            res.onSuccess { msg -> showBanner(msg) }
                .onFailure { err -> showBanner(err.message ?: "Restore failed", isError = true) }
        }
    }

    fun dismissBackupPreview() {
        _uiState.update { it.copy(pendingBackupPreview = null) }
    }

    // External Octapad Backup Import
    fun importExternalBackup(uri: Uri) {
        val bank = _uiState.value.selectedBank
        val num = _uiState.value.selectedPatchNumber
        viewModelScope.launch {
            val outcome = externalBackupImporter.inspectAndConvert(uri, bank, num)
            if (outcome is ExternalImportOutcome.Imported) {
                repository.savePatch(outcome.patch)
                syncActivePatchCache(outcome.patch)
            }
            _uiState.update { it.copy(externalImportOutcome = outcome) }
        }
    }

    fun dismissExternalImportOutcome() {
        _uiState.update { it.copy(externalImportOutcome = null) }
    }

    fun clearBanner() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    private fun showBanner(message: String, isError: Boolean = false) {
        _uiState.update {
            it.copy(
                statusBannerMessage = message,
                statusBannerIsError = isError
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        midiManager.stop()
        audioEngine.releaseAudio()
    }
}
