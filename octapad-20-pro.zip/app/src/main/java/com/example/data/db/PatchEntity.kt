package com.example.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import com.example.data.model.Bank
import com.example.data.model.CustomSample
import com.example.data.model.PadConfig
import com.example.data.model.Patch

@Entity(
    tableName = "patches",
    primaryKeys = ["bank", "patchNumber"]
)
data class PatchEntity(
    val bank: String,
    val patchNumber: Int,
    val name: String,
    val isFavorite: Boolean = false,
    val updatedAt: Long = 0L
)

@Entity(
    tableName = "pad_configs",
    primaryKeys = ["bank", "patchNumber", "padIndex"],
    foreignKeys = [
        ForeignKey(
            entity = PatchEntity::class,
            parentColumns = ["bank", "patchNumber"],
            childColumns = ["bank", "patchNumber"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["bank", "patchNumber"])]
)
data class PadConfigEntity(
    val bank: String,
    val patchNumber: Int,
    val padIndex: Int,
    val soundId: String,
    val soundName: String,
    val isCustomSample: Boolean = false,
    val customSamplePath: String? = null,
    val volume: Float = 0.90f,
    val pitch: Float = 1.0f,
    val pan: Float = 0.0f,
    val enabled: Boolean = true,
    val borderColorHex: Long
)

@Entity(tableName = "custom_samples")
data class CustomSampleEntity(
    @PrimaryKey val sampleId: String,
    val displayName: String,
    val filePath: String,
    val mimeType: String,
    val durationMs: Long,
    val fileSizeBytes: Long,
    val createdAt: Long
)

data class PatchWithPads(
    @Embedded val patch: PatchEntity,
    @Relation(
        parentColumn = "bank",
        entityColumn = "bank",
        entity = PadConfigEntity::class
    )
    val allBankPads: List<PadConfigEntity>
)

// Note: Room @Relation matches only 1 column, so for composite keys (bank, patchNumber)
// we also provide explicit queries or filter cleanly by patchNumber in mapper.
// Even better: query PatchEntity + PadConfigEntity explicitly or use a dedicated @Query with @Transaction.
fun PatchEntity.toDomain(pads: List<PadConfigEntity>): Patch = Patch(
    bank = Bank.fromId(bank),
    number = patchNumber,
    name = name,
    isFavorite = isFavorite,
    pads = pads.sortedBy { it.padIndex }.map { it.toDomain() },
    updatedAt = updatedAt
)

fun PadConfigEntity.toDomain(): PadConfig = PadConfig(
    padIndex = padIndex,
    soundId = soundId,
    soundName = soundName,
    isCustomSample = isCustomSample,
    customSamplePath = customSamplePath,
    volume = volume,
    pitch = pitch,
    pan = pan,
    enabled = enabled,
    borderColorHex = borderColorHex
)

fun PadConfig.toEntity(bank: Bank, patchNumber: Int): PadConfigEntity = PadConfigEntity(
    bank = bank.id,
    patchNumber = patchNumber,
    padIndex = padIndex,
    soundId = soundId,
    soundName = soundName,
    isCustomSample = isCustomSample,
    customSamplePath = customSamplePath,
    volume = volume,
    pitch = pitch,
    pan = pan,
    enabled = enabled,
    borderColorHex = borderColorHex
)

fun Patch.toEntity(): PatchEntity = PatchEntity(
    bank = bank.id,
    patchNumber = number,
    name = name,
    isFavorite = isFavorite,
    updatedAt = updatedAt
)

fun CustomSampleEntity.toDomain(): CustomSample = CustomSample(
    sampleId = sampleId,
    displayName = displayName,
    filePath = filePath,
    mimeType = mimeType,
    durationMs = durationMs,
    fileSizeBytes = fileSizeBytes,
    createdAt = createdAt
)

fun CustomSample.toEntity(): CustomSampleEntity = CustomSampleEntity(
    sampleId = sampleId,
    displayName = displayName,
    filePath = filePath,
    mimeType = mimeType,
    durationMs = durationMs,
    fileSizeBytes = fileSizeBytes,
    createdAt = createdAt
)
