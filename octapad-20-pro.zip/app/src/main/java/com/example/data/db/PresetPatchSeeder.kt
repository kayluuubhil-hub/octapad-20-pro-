package com.example.data.db

import com.example.data.model.Bank
import com.example.data.model.BundledSoundCatalog
import com.example.data.model.PadConfig
import com.example.ui.theme.DefaultPadColors

object PresetPatchSeeder {

    private data class KitTemplate(
        val baseName: String,
        val soundIds: List<String> // exactly 8 sound IDs
    )

    private val bankAKitTemplates: List<KitTemplate> = listOf(
        KitTemplate(
            "Salpuri",
            listOf("dhol_bass", "dhol_tali", "timli_duff", "manjira_ring", "dhol_roll", "dholak_na", "dholak_ge", "crash_cymbal")
        ),
        KitTemplate(
            "Timli Special",
            listOf("timli_duff", "dhol_bass", "dhol_tali", "manjira_ring", "clap_studio", "kick_punch", "hihat_closed", "crash_cymbal")
        ),
        KitTemplate(
            "Gamit Special",
            listOf("dholak_ge", "dholak_na", "timli_duff", "manjira_ring", "dhol_bass", "dhol_tali", "shaker_maraca", "hihat_open")
        ),
        KitTemplate(
            "Dhol Special",
            listOf("dhol_bass", "dhol_tali", "dhol_roll", "timli_duff", "tabla_na", "manjira_ring", "kick_punch", "crash_cymbal")
        ),
        KitTemplate(
            "Adivasi Special",
            listOf("dhol_bass", "timli_duff", "dhol_tali", "woodblock", "manjira_ring", "shaker_maraca", "dhol_roll", "conga_slap")
        ),
        KitTemplate(
            "Festival Special",
            listOf("kick_808", "dhol_bass", "snare_tight", "dhol_tali", "clap_studio", "manjira_ring", "hihat_open", "crash_cymbal")
        ),
        KitTemplate(
            "Garba Dandiya",
            listOf("dhol_bass", "dhol_tali", "dholak_na", "manjira_ring", "woodblock", "clap_studio", "hihat_closed", "ride_bell")
        ),
        KitTemplate(
            "Tabla Classical",
            listOf("tabla_ge", "tabla_na", "dholak_ge", "dholak_na", "manjira_ring", "shaker_maraca", "conga_low", "ride_bell")
        ),
        KitTemplate(
            "Acoustic Studio",
            listOf("kick_punch", "snare_tight", "hihat_closed", "hihat_open", "crash_cymbal", "tom_high", "tom_mid", "tom_low")
        ),
        KitTemplate(
            "808 Electronic",
            listOf("kick_808", "snare_rim", "hihat_closed", "hihat_open", "clap_studio", "cowbell", "fx_laser", "crash_cymbal")
        ),
        KitTemplate(
            "Latin Percussion",
            listOf("conga_low", "conga_slap", "bongo_high", "cowbell", "woodblock", "shaker_maraca", "snare_rim", "ride_bell")
        ),
        KitTemplate(
            "Bhangra Dhol",
            listOf("dhol_bass", "dhol_tali", "dhol_roll", "kick_punch", "clap_studio", "chimta" .let { "manjira_ring" }, "timli_duff", "crash_cymbal")
        ),
        KitTemplate(
            "Desi DJ Club",
            listOf("kick_808", "clap_studio", "dhol_bass", "dhol_tali", "hihat_closed", "hihat_open", "fx_laser", "crash_cymbal")
        ),
        KitTemplate(
            "Navratri Raas",
            listOf("dholak_ge", "dholak_na", "timli_duff", "manjira_ring", "woodblock", "dhol_roll", "tabla_na", "ride_bell")
        ),
        KitTemplate(
            "Fusion Stage",
            listOf("kick_punch", "snare_tight", "tabla_ge", "tabla_na", "conga_slap", "hihat_closed", "tom_mid", "crash_cymbal")
        ),
        KitTemplate(
            "Tribal Groove",
            listOf("dhol_bass", "conga_low", "conga_slap", "woodblock", "timli_duff", "shaker_maraca", "bongo_high", "tom_low")
        )
    )

    private val bankBKitTemplates: List<KitTemplate> = listOf(
        KitTemplate(
            "Salpuri Pro",
            listOf("dhol_bass", "dhol_roll", "timli_duff", "manjira_ring", "kick_808", "dhol_tali", "clap_studio", "crash_cymbal")
        ),
        KitTemplate(
            "Timli Stage",
            listOf("timli_duff", "dhol_roll", "dhol_bass", "manjira_ring", "snare_rim", "kick_808", "hihat_open", "ride_bell")
        ),
        KitTemplate(
            "Gamit Remix",
            listOf("dholak_ge", "dholak_na", "kick_808", "manjira_ring", "clap_studio", "timli_duff", "hihat_closed", "fx_laser")
        ),
        KitTemplate(
            "Dhol Thunder",
            listOf("dhol_bass", "kick_808", "dhol_tali", "dhol_roll", "timli_duff", "manjira_ring", "tom_low", "crash_cymbal")
        ),
        KitTemplate(
            "Adivasi Groove",
            listOf("dhol_bass", "timli_duff", "woodblock", "conga_slap", "manjira_ring", "dhol_tali", "shaker_maraca", "dhol_roll")
        ),
        KitTemplate(
            "Festival EDM",
            listOf("kick_808", "clap_studio", "fx_laser", "dhol_tali", "hihat_closed", "hihat_open", "tom_high", "crash_cymbal")
        ),
        KitTemplate(
            "Garba Power",
            listOf("dhol_bass", "dhol_tali", "woodblock", "manjira_ring", "dholak_na", "kick_punch", "clap_studio", "crash_cymbal")
        ),
        KitTemplate(
            "Tabla Lounge",
            listOf("tabla_ge", "tabla_na", "kick_808", "snare_rim", "hihat_closed", "shaker_maraca", "conga_low", "ride_bell")
        ),
        KitTemplate(
            "Rock Arena",
            listOf("kick_punch", "snare_tight", "tom_high", "tom_mid", "tom_low", "hihat_closed", "hihat_open", "crash_cymbal")
        ),
        KitTemplate(
            "Trap 808",
            listOf("kick_808", "snare_tight", "clap_studio", "hihat_closed", "hihat_open", "snare_rim", "fx_laser", "cowbell")
        ),
        KitTemplate(
            "Salsa Fiesta",
            listOf("conga_low", "conga_slap", "bongo_high", "cowbell", "woodblock", "shaker_maraca", "tom_high", "crash_cymbal")
        ),
        KitTemplate(
            "Dandiya Beat",
            listOf("woodblock", "dhol_tali", "dhol_bass", "manjira_ring", "timli_duff", "clap_studio", "shaker_maraca", "ride_bell")
        ),
        KitTemplate(
            "Bollywood Live",
            listOf("kick_punch", "dholak_ge", "dholak_na", "snare_tight", "clap_studio", "manjira_ring", "hihat_closed", "crash_cymbal")
        ),
        KitTemplate(
            "Percussion Solo",
            listOf("tabla_na", "tabla_ge", "conga_slap", "bongo_high", "dhol_roll", "woodblock", "cowbell", "shaker_maraca")
        ),
        KitTemplate(
            "Synthwave 80s",
            listOf("kick_punch", "snare_tight", "clap_studio", "tom_high", "tom_mid", "tom_low", "fx_laser", "crash_cymbal")
        ),
        KitTemplate(
            "Custom Patch",
            listOf("kick_punch", "snare_tight", "hihat_closed", "hihat_open", "tom_high", "tom_mid", "tom_low", "crash_cymbal")
        )
    )

    private val bankASuffixes = listOf(
        "", " II", " Live", " Folk", " Mix", " Acoustic", " Studio", " Express"
    )

    private val bankBSuffixes = listOf(
        "", " Pro", " Club", " Heavy", " Stage", " Master", " Deluxe", " Remix"
    )

    fun generateInitialPatches(): Pair<List<PatchEntity>, List<PadConfigEntity>> {
        val patches = ArrayList<PatchEntity>(200)
        val pads = ArrayList<PadConfigEntity>(1600)
        val now = System.currentTimeMillis()

        // Bank A: 1..100
        for (number in 1..100) {
            val idx = number - 1
            val template = when {
                number == 100 -> KitTemplate(
                    "Custom Patch",
                    listOf("kick_punch", "snare_tight", "hihat_closed", "hihat_open", "tom_high", "tom_mid", "tom_low", "crash_cymbal")
                )
                idx < bankAKitTemplates.size -> bankAKitTemplates[idx]
                else -> bankAKitTemplates[idx % bankAKitTemplates.size]
            }
            val patchName = when {
                number <= bankAKitTemplates.size || number == 100 -> template.baseName
                else -> {
                    val cycle = (idx / bankAKitTemplates.size)
                    val suffix = bankASuffixes[cycle % bankASuffixes.size]
                    "${template.baseName}$suffix $number".trim()
                }
            }
            val isFav = number in setOf(1, 2, 3, 4, 5, 6)
            patches.add(
                PatchEntity(
                    bank = Bank.A.id,
                    patchNumber = number,
                    name = patchName,
                    isFavorite = isFav,
                    updatedAt = now
                )
            )
            // Slight pitch/volume variation per patch index so every patch has an independent configuration
            val pitchOffset = if (number <= 16) 1.0f else (0.94f + (number % 5) * 0.03f)
            template.soundIds.forEachIndexed { padIndex, soundId ->
                val sound = BundledSoundCatalog.findById(soundId)
                pads.add(
                    PadConfigEntity(
                        bank = Bank.A.id,
                        patchNumber = number,
                        padIndex = padIndex,
                        soundId = sound.id,
                        soundName = sound.displayName,
                        isCustomSample = false,
                        customSamplePath = null,
                        volume = 0.90f,
                        pitch = if (padIndex == 0 || padIndex == 7) 1.0f else pitchOffset,
                        pan = when (padIndex % 4) {
                            0 -> -0.15f
                            3 -> 0.15f
                            else -> 0.0f
                        },
                        enabled = true,
                        borderColorHex = DefaultPadColors[padIndex]
                    )
                )
            }
        }

        // Bank B: 1..100
        for (number in 1..100) {
            val idx = number - 1
            val template = when {
                number == 100 -> bankBKitTemplates.last()
                idx < bankBKitTemplates.size -> bankBKitTemplates[idx]
                else -> bankBKitTemplates[idx % bankBKitTemplates.size]
            }
            val patchName = when {
                number <= bankBKitTemplates.size || number == 100 -> template.baseName
                else -> {
                    val cycle = (idx / bankBKitTemplates.size)
                    val suffix = bankBSuffixes[cycle % bankBSuffixes.size]
                    "${template.baseName}$suffix $number".trim()
                }
            }
            val isFav = number in setOf(1, 4)
            patches.add(
                PatchEntity(
                    bank = Bank.B.id,
                    patchNumber = number,
                    name = patchName,
                    isFavorite = isFav,
                    updatedAt = now
                )
            )
            val pitchOffset = if (number <= 16) 1.02f else (0.96f + (number % 4) * 0.03f)
            template.soundIds.forEachIndexed { padIndex, soundId ->
                val sound = BundledSoundCatalog.findById(soundId)
                pads.add(
                    PadConfigEntity(
                        bank = Bank.B.id,
                        patchNumber = number,
                        padIndex = padIndex,
                        soundId = sound.id,
                        soundName = sound.displayName,
                        isCustomSample = false,
                        customSamplePath = null,
                        volume = 0.92f,
                        pitch = if (padIndex == 0) 1.0f else pitchOffset,
                        pan = when (padIndex % 4) {
                            0 -> -0.20f
                            3 -> 0.20f
                            else -> 0.0f
                        },
                        enabled = true,
                        borderColorHex = DefaultPadColors[padIndex]
                    )
                )
            }
        }

        return patches to pads
    }

    fun defaultCleanPads(): List<PadConfig> {
        val defaultIds = listOf(
            "kick_punch", "snare_tight", "hihat_closed", "hihat_open",
            "tom_high", "tom_mid", "tom_low", "crash_cymbal"
        )
        return defaultIds.mapIndexed { index, soundId ->
            val sound = BundledSoundCatalog.findById(soundId)
            PadConfig(
                padIndex = index,
                soundId = sound.id,
                soundName = sound.displayName,
                volume = 0.90f,
                pitch = 1.0f,
                pan = 0.0f,
                enabled = true,
                borderColorHex = DefaultPadColors[index]
            )
        }
    }
}
