package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AudioEffectsConfig
import com.example.data.model.Bank
import com.example.data.model.MidiConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.octapadDataStore: DataStore<Preferences> by preferencesDataStore(name = "octapad_prefs")

data class UserPreferences(
    val selectedBank: Bank = Bank.A,
    val selectedPatchNumber: Int = 1,
    val masterVolume: Float = 0.90f,
    val effects: AudioEffectsConfig = AudioEffectsConfig(),
    val midiConfig: MidiConfig = MidiConfig()
)

class PreferencesManager(private val context: Context) {

    private object Keys {
        val SELECTED_BANK = stringPreferencesKey("selected_bank")
        val SELECTED_PATCH = intPreferencesKey("selected_patch")
        val MASTER_VOLUME = floatPreferencesKey("master_volume")
        val EFFECTS_ENABLED = booleanPreferencesKey("effects_enabled")
        val REVERB_LEVEL = floatPreferencesKey("reverb_level")
        val DELAY_LEVEL = floatPreferencesKey("delay_level")
        val BASS_BOOST = floatPreferencesKey("bass_boost")
        val MID_GAIN = floatPreferencesKey("mid_gain")
        val TREBLE_GAIN = floatPreferencesKey("treble_gain")
        val MIDI_MAPPING_JSON = stringPreferencesKey("midi_mapping_json")
    }

    val preferencesFlow: Flow<UserPreferences> = context.octapadDataStore.data.map { prefs ->
        val bank = Bank.fromId(prefs[Keys.SELECTED_BANK] ?: "A")
        val patchNumber = (prefs[Keys.SELECTED_PATCH] ?: 1).coerceIn(1, 100)
        val masterVolume = (prefs[Keys.MASTER_VOLUME] ?: 0.90f).coerceIn(0f, 1f)
        val effects = AudioEffectsConfig(
            effectsEnabled = prefs[Keys.EFFECTS_ENABLED] ?: false,
            reverbLevel = (prefs[Keys.REVERB_LEVEL] ?: 0.20f).coerceIn(0f, 1f),
            delayLevel = (prefs[Keys.DELAY_LEVEL] ?: 0.0f).coerceIn(0f, 1f),
            bassBoost = (prefs[Keys.BASS_BOOST] ?: 0.0f).coerceIn(-1f, 1f),
            midGain = (prefs[Keys.MID_GAIN] ?: 0.0f).coerceIn(-1f, 1f),
            trebleGain = (prefs[Keys.TREBLE_GAIN] ?: 0.0f).coerceIn(-1f, 1f)
        )
        val midiMap = parseMidiMapping(prefs[Keys.MIDI_MAPPING_JSON])
        UserPreferences(
            selectedBank = bank,
            selectedPatchNumber = patchNumber,
            masterVolume = masterVolume,
            effects = effects,
            midiConfig = MidiConfig(midiMap)
        )
    }

    suspend fun setSelectedBankAndPatch(bank: Bank, patchNumber: Int) {
        context.octapadDataStore.edit { prefs ->
            prefs[Keys.SELECTED_BANK] = bank.id
            prefs[Keys.SELECTED_PATCH] = patchNumber.coerceIn(1, 100)
        }
    }

    suspend fun setMasterVolume(volume: Float) {
        context.octapadDataStore.edit { prefs ->
            prefs[Keys.MASTER_VOLUME] = volume.coerceIn(0f, 1f)
        }
    }

    suspend fun setEffectsConfig(config: AudioEffectsConfig) {
        context.octapadDataStore.edit { prefs ->
            prefs[Keys.EFFECTS_ENABLED] = config.effectsEnabled
            prefs[Keys.REVERB_LEVEL] = config.reverbLevel.coerceIn(0f, 1f)
            prefs[Keys.DELAY_LEVEL] = config.delayLevel.coerceIn(0f, 1f)
            prefs[Keys.BASS_BOOST] = config.bassBoost.coerceIn(-1f, 1f)
            prefs[Keys.MID_GAIN] = config.midGain.coerceIn(-1f, 1f)
            prefs[Keys.TREBLE_GAIN] = config.trebleGain.coerceIn(-1f, 1f)
        }
    }

    suspend fun setMidiMapping(noteToPad: Map<Int, Int>) {
        val json = JSONObject().apply {
            noteToPad.forEach { (note, padIndex) ->
                put(note.toString(), padIndex)
            }
        }.toString()
        context.octapadDataStore.edit { prefs ->
            prefs[Keys.MIDI_MAPPING_JSON] = json
        }
    }

    private fun parseMidiMapping(raw: String?): Map<Int, Int> {
        if (raw.isNullOrBlank()) return MidiConfig.defaultNoteMapping()
        return try {
            val obj = JSONObject(raw)
            val map = mutableMapOf<Int, Int>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val note = k.toIntOrNull()
                val pad = obj.optInt(k, -1)
                if (note != null && note in 0..127 && pad in 0..7) {
                    map[note] = pad
                }
            }
            if (map.isEmpty()) MidiConfig.defaultNoteMapping() else map
        } catch (_: Exception) {
            MidiConfig.defaultNoteMapping()
        }
    }
}
