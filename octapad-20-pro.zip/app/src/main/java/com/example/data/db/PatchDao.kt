package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface PatchDao {

    @Query("SELECT COUNT(*) FROM patches")
    suspend fun getPatchCount(): Int

    @Query("SELECT * FROM patches WHERE bank = :bank ORDER BY patchNumber ASC")
    fun observePatchesByBank(bank: String): Flow<List<PatchEntity>>

    @Query("SELECT * FROM pad_configs WHERE bank = :bank ORDER BY patchNumber ASC, padIndex ASC")
    fun observePadsByBank(bank: String): Flow<List<PadConfigEntity>>

    @Query("SELECT * FROM patches WHERE isFavorite = 1 ORDER BY bank ASC, patchNumber ASC")
    fun observeFavoritePatches(): Flow<List<PatchEntity>>

    @Query("SELECT * FROM patches ORDER BY bank ASC, patchNumber ASC")
    suspend fun getAllPatches(): List<PatchEntity>

    @Query("SELECT * FROM pad_configs ORDER BY bank ASC, patchNumber ASC, padIndex ASC")
    suspend fun getAllPads(): List<PadConfigEntity>

    @Query("SELECT * FROM patches WHERE bank = :bank AND patchNumber = :patchNumber LIMIT 1")
    suspend fun getPatch(bank: String, patchNumber: Int): PatchEntity?

    @Query("SELECT * FROM pad_configs WHERE bank = :bank AND patchNumber = :patchNumber ORDER BY padIndex ASC")
    suspend fun getPadsForPatch(bank: String, patchNumber: Int): List<PadConfigEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatches(patches: List<PatchEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatch(patch: PatchEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPads(pads: List<PadConfigEntity>)

    @Query("UPDATE patches SET isFavorite = :isFavorite, updatedAt = :updatedAt WHERE bank = :bank AND patchNumber = :patchNumber")
    suspend fun updateFavorite(bank: String, patchNumber: Int, isFavorite: Boolean, updatedAt: Long)

    @Transaction
    suspend fun savePatchWithPads(patch: PatchEntity, pads: List<PadConfigEntity>) {
        insertPatch(patch)
        insertPads(pads)
    }

    @Transaction
    suspend fun seedAll(patches: List<PatchEntity>, pads: List<PadConfigEntity>) {
        insertPatches(patches)
        insertPads(pads)
    }

    // Custom samples
    @Query("SELECT * FROM custom_samples ORDER BY createdAt DESC")
    fun observeCustomSamples(): Flow<List<CustomSampleEntity>>

    @Query("SELECT * FROM custom_samples ORDER BY createdAt DESC")
    suspend fun getAllCustomSamples(): List<CustomSampleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomSample(sample: CustomSampleEntity)

    @Query("DELETE FROM custom_samples WHERE sampleId = :sampleId")
    suspend fun deleteCustomSample(sampleId: String)
}
