package com.example.data

import com.example.data.db.PatchDao
import com.example.data.db.PresetPatchSeeder
import com.example.data.db.toDomain
import com.example.data.db.toEntity
import com.example.data.model.Bank
import com.example.data.model.CustomSample
import com.example.data.model.Patch
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class PatchRepository(private val patchDao: PatchDao) {

    suspend fun ensureSeeded() {
        if (patchDao.getPatchCount() < 200) {
            val (patches, pads) = PresetPatchSeeder.generateInitialPatches()
            patchDao.seedAll(patches, pads)
        }
    }

    fun observeBankPatches(bank: Bank): Flow<Map<Int, Patch>> {
        return combine(
            patchDao.observePatchesByBank(bank.id),
            patchDao.observePadsByBank(bank.id)
        ) { patchEntities, padEntities ->
            val padsByPatch = padEntities.groupBy { it.patchNumber }
            patchEntities.associate { entity ->
                val patchPads = padsByPatch[entity.patchNumber].orEmpty()
                entity.patchNumber to entity.toDomain(patchPads)
            }
        }
    }

    fun observeFavorites(): Flow<List<Patch>> {
        return combine(
            patchDao.observeFavoritePatches(),
            patchDao.observePadsByBank(Bank.A.id),
            patchDao.observePadsByBank(Bank.B.id)
        ) { favEntities, padsA, padsB ->
            val padsAByPatch = padsA.groupBy { it.patchNumber }
            val padsBByPatch = padsB.groupBy { it.patchNumber }
            favEntities.map { entity ->
                val pads = if (entity.bank == Bank.A.id) {
                    padsAByPatch[entity.patchNumber].orEmpty()
                } else {
                    padsBByPatch[entity.patchNumber].orEmpty()
                }
                entity.toDomain(pads)
            }
        }
    }

    fun observeCustomSamples(): Flow<List<CustomSample>> {
        return patchDao.observeCustomSamples().map { list -> list.map { it.toDomain() } }
    }

    suspend fun getAllCustomSamples(): List<CustomSample> {
        return patchDao.getAllCustomSamples().map { it.toDomain() }
    }

    suspend fun getPatch(bank: Bank, patchNumber: Int): Patch? {
        val patch = patchDao.getPatch(bank.id, patchNumber) ?: return null
        val pads = patchDao.getPadsForPatch(bank.id, patchNumber)
        return patch.toDomain(pads)
    }

    suspend fun getAllPatches(): List<Patch> {
        val patches = patchDao.getAllPatches()
        val allPads = patchDao.getAllPads().groupBy { it.bank to it.patchNumber }
        return patches.map { entity ->
            entity.toDomain(allPads[entity.bank to entity.patchNumber].orEmpty())
        }
    }

    suspend fun savePatch(patch: Patch) {
        val now = System.currentTimeMillis()
        val updated = patch.copy(updatedAt = now)
        val padEntities = updated.pads.map { it.toEntity(updated.bank, updated.number) }
        patchDao.savePatchWithPads(updated.toEntity(), padEntities)
    }

    suspend fun savePatchesBulk(patches: List<Patch>) {
        val now = System.currentTimeMillis()
        val patchEntities = patches.map { it.copy(updatedAt = now).toEntity() }
        val padEntities = patches.flatMap { patch ->
            patch.pads.map { pad -> pad.toEntity(patch.bank, patch.number) }
        }
        patchDao.seedAll(patchEntities, padEntities)
    }

    suspend fun copyPatch(
        sourceBank: Bank,
        sourceNumber: Int,
        targetBank: Bank,
        targetNumber: Int
    ): Patch? {
        val source = getPatch(sourceBank, sourceNumber) ?: return null
        val now = System.currentTimeMillis()
        val copied = source.copy(
            bank = targetBank,
            number = targetNumber,
            updatedAt = now
        )
        savePatch(copied)
        return copied
    }

    suspend fun clearPatch(bank: Bank, patchNumber: Int): Patch {
        val now = System.currentTimeMillis()
        val cleared = Patch(
            bank = bank,
            number = patchNumber,
            name = "Custom Patch $patchNumber",
            isFavorite = false,
            pads = PresetPatchSeeder.defaultCleanPads(),
            updatedAt = now
        )
        savePatch(cleared)
        return cleared
    }

    suspend fun toggleFavorite(bank: Bank, patchNumber: Int, isFavorite: Boolean) {
        patchDao.updateFavorite(
            bank = bank.id,
            patchNumber = patchNumber,
            isFavorite = isFavorite,
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun addCustomSample(sample: CustomSample) {
        patchDao.insertCustomSample(sample.toEntity())
    }

    suspend fun removeCustomSample(sampleId: String) {
        patchDao.deleteCustomSample(sampleId)
    }
}
