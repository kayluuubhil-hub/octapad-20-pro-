package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PatchEntity::class,
        PadConfigEntity::class,
        CustomSampleEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class OctapadDatabase : RoomDatabase() {
    abstract fun patchDao(): PatchDao

    companion object {
        @Volatile
        private var INSTANCE: OctapadDatabase? = null

        fun getInstance(context: Context): OctapadDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    OctapadDatabase::class.java,
                    "octapad20pro.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
