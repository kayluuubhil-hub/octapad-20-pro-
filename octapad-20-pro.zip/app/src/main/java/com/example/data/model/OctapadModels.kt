package com.example.data.model

import com.example.R
import com.example.ui.theme.DefaultPadColors

enum class Bank(val id: String, val label: String) {
    A("A", "BANK A"),
    B("B", "BANK B");

    companion object {
        fun fromId(id: String): Bank = if (id.equals("B", ignoreCase = true)) B else A
    }
}

data class BundledSound(
    val id: String,
    val displayName: String,
    val category: String,
    val rawResId: Int
)

object BundledSoundCatalog {
    val sounds: List<BundledSound> = listOf(
        BundledSound("kick_punch", "Punch Kick", "Kick", R.raw.snd_kick_punch),
        BundledSound("kick_808", "808 Sub Kick", "Kick", R.raw.snd_kick_808),
        BundledSound("snare_tight", "Tight Snare", "Snare", R.raw.snd_snare_tight),
        BundledSound("snare_rim", "Rimshot", "Snare", R.raw.snd_snare_rim),
        BundledSound("hihat_closed", "Closed Hat", "Cymbal", R.raw.snd_hihat_closed),
        BundledSound("hihat_open", "Open Hat", "Cymbal", R.raw.snd_hihat_open),
        BundledSound("crash_cymbal", "Crash Cymbal", "Cymbal", R.raw.snd_crash_cymbal),
        BundledSound("ride_bell", "Ride Bell", "Cymbal", R.raw.snd_ride_bell),
        BundledSound("tom_high", "High Tom", "Tom", R.raw.snd_tom_high),
        BundledSound("tom_mid", "Mid Tom", "Tom", R.raw.snd_tom_mid),
        BundledSound("tom_low", "Floor Tom", "Tom", R.raw.snd_tom_low),
        BundledSound("clap_studio", "Studio Clap", "Electronic", R.raw.snd_clap_studio),
        BundledSound("dhol_bass", "Dhol Bass", "Indian Folk", R.raw.snd_dhol_bass),
        BundledSound("dhol_tali", "Dhol Tali", "Indian Folk", R.raw.snd_dhol_tali),
        BundledSound("dhol_roll", "Dhol Roll", "Indian Folk", R.raw.snd_dhol_roll),
        BundledSound("dholak_na", "Dholak Na", "Indian Folk", R.raw.snd_dholak_na),
        BundledSound("dholak_ge", "Dholak Ge", "Indian Folk", R.raw.snd_dholak_ge),
        BundledSound("tabla_na", "Tabla Na", "Indian Folk", R.raw.snd_tabla_na),
        BundledSound("tabla_ge", "Tabla Ge", "Indian Folk", R.raw.snd_tabla_ge),
        BundledSound("timli_duff", "Timli Duff", "Indian Folk", R.raw.snd_timli_duff),
        BundledSound("manjira_ring", "Manjira Ring", "Indian Folk", R.raw.snd_manjira_ring),
        BundledSound("conga_slap", "Conga Slap", "Percussion", R.raw.snd_conga_slap),
        BundledSound("conga_low", "Conga Low", "Percussion", R.raw.snd_conga_low),
        BundledSound("bongo_high", "Bongo High", "Percussion", R.raw.snd_bongo_high),
        BundledSound("cowbell", "Cowbell", "Percussion", R.raw.snd_cowbell),
        BundledSound("woodblock", "Woodblock", "Percussion", R.raw.snd_woodblock),
        BundledSound("shaker_maraca", "Shaker", "Percussion", R.raw.snd_shaker_maraca),
        BundledSound("fx_laser", "Synth Zap", "Electronic", R.raw.snd_fx_laser)
    )

    val byId: Map<String, BundledSound> = sounds.associateBy { it.id }

    fun findById(id: String): BundledSound = byId[id] ?: sounds.first()
}

data class PadConfig(
    val padIndex: Int, // 0..7 -> PAD 1..PAD 8
    val soundId: String,
    val soundName: String,
    val isCustomSample: Boolean = false,
    val customSamplePath: String? = null,
    val volume: Float = 0.90f,
    val pitch: Float = 1.0f, // 0.5f .. 2.0f
    val pan: Float = 0.0f,   // -1.0f .. 1.0f
    val enabled: Boolean = true,
    val borderColorHex: Long = DefaultPadColors[padIndex.coerceIn(0, 7)]
) {
    val padLabel: String get() = "PAD ${padIndex + 1}"
}

data class Patch(
    val bank: Bank,
    val number: Int, // 1..100
    val name: String,
    val isFavorite: Boolean = false,
    val pads: List<PadConfig>,
    val updatedAt: Long = 0L
) {
    val codeLabel: String get() = "${bank.id}-$number"
}

data class CustomSample(
    val sampleId: String,
    val displayName: String,
    val filePath: String,
    val mimeType: String,
    val durationMs: Long,
    val fileSizeBytes: Long,
    val createdAt: Long
)

data class AudioEffectsConfig(
    val effectsEnabled: Boolean = false,
    val reverbLevel: Float = 0.20f,
    val delayLevel: Float = 0.0f,
    val bassBoost: Float = 0.0f,   // -1.0 .. 1.0
    val midGain: Float = 0.0f,     // -1.0 .. 1.0
    val trebleGain: Float = 0.0f   // -1.0 .. 1.0
)

data class MidiConfig(
    // MIDI note (0..127) -> padIndex (0..7)
    val noteToPad: Map<Int, Int> = defaultNoteMapping()
) {
    fun padToNoteMap(): Map<Int, Int> {
        val out = mutableMapOf<Int, Int>()
        noteToPad.forEach { (note, pad) ->
            if (pad in 0..7 && !out.containsKey(pad)) {
                out[pad] = note
            }
        }
        return out
    }

    companion object {
        // Standard GM Percussion default mapping for 8 pads
        fun defaultNoteMapping(): Map<Int, Int> = mapOf(
            36 to 0, // PAD 1: Bass Drum 1
            38 to 1, // PAD 2: Acoustic Snare
            42 to 2, // PAD 3: Closed Hi-Hat
            46 to 3, // PAD 4: Open Hi-Hat
            49 to 4, // PAD 5: Crash Cymbal 1
            48 to 5, // PAD 6: Hi-Mid Tom
            45 to 6, // PAD 7: Low Tom
            51 to 7  // PAD 8: Ride Cymbal 1
        )
    }
}

data class MidiStatus(
    val isSupported: Boolean = false,
    val isConnected: Boolean = false,
    val connectedDevices: List<String> = emptyList(),
    val lastNote: Int? = null,
    val lastPadTriggered: Int? = null
)

data class AudioEngineStatus(
    val isInitialized: Boolean = false,
    val loadedBundledCount: Int = 0,
    val totalBundledCount: Int = BundledSoundCatalog.sounds.size,
    val loadedCustomCount: Int = 0,
    val activeStreams: Int = 0,
    val sampleRateHz: Int = 44100,
    val framesPerBuffer: Int = 256,
    val hasAudioFocus: Boolean = false,
    val effectsHardwareSupported: Boolean = false
)

enum class AppRoute {
    PLAY,
    PATCH_EDITOR,
    SETTINGS
}
