package com.example

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppRoute
import com.example.ui.screens.OctapadScreen
import com.example.ui.screens.PatchEditor
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.LedCyan
import com.example.ui.theme.OctapadTheme
import com.example.viewmodel.PatchViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PatchViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enforce landscape-only hardware drum-machine orientation at runtime as well as manifest
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        enableEdgeToEdge()

        // Immersive sticky bars for maximum horizontal playing surface
        WindowCompat.getInsetsController(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.statusBars())
        }

        setContent {
            OctapadTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                if (!uiState.isReady && uiState.bankAPatches.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ChassisBlack),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = LedCyan)
                    }
                } else {
                    when (uiState.currentRoute) {
                        AppRoute.PLAY -> {
                            OctapadScreen(
                                uiState = uiState,
                                padHitPulseFlows = viewModel.padHitPulseFlows,
                                onTriggerPad = viewModel::triggerPad,
                                onSelectBank = viewModel::selectBank,
                                onSelectPatch = viewModel::selectPatch,
                                onSelectBankAndPatch = viewModel::selectBankAndPatch,
                                onToggleFavorite = viewModel::toggleCurrentPatchFavorite,
                                onToggleFavoritesFilter = viewModel::toggleFavoriteFilterInBar,
                                onSavePatch = viewModel::saveCurrentPatch,
                                onShowLoadDialog = viewModel::setShowLoadDialog,
                                onReloadCurrentPatch = viewModel::reloadCurrentPatchFromStorage,
                                onOpenEditor = { viewModel.openPatchEditor(0) },
                                onShowCopyDialog = viewModel::setShowCopyDialog,
                                onConfirmCopyPatch = viewModel::copyCurrentPatchTo,
                                onShowClearDialog = viewModel::setShowClearConfirmDialog,
                                onConfirmClearPatch = viewModel::confirmClearCurrentPatch,
                                onOpenSettings = viewModel::openSettings,
                                onMasterVolumeChange = viewModel::setMasterVolume,
                                onClearBanner = viewModel::clearBanner
                            )
                        }

                        AppRoute.PATCH_EDITOR -> {
                            val editing = uiState.editingPatch ?: uiState.currentPatch
                            PatchEditor(
                                editingPatch = editing,
                                selectedPadIndex = uiState.editingPadIndex,
                                customSamples = uiState.customSamples,
                                statusBannerMessage = uiState.statusBannerMessage,
                                statusBannerIsError = uiState.statusBannerIsError,
                                onSelectPad = viewModel::selectEditingPad,
                                onUpdatePatch = viewModel::updateEditingPatch,
                                onPreviewSound = viewModel::previewSound,
                                onImportSampleUri = { uri -> viewModel.importSampleFromUri(uri, assignToEditingPad = true) },
                                onSave = viewModel::saveEditingPatch,
                                onCancel = viewModel::cancelPatchEditor
                            )
                        }

                        AppRoute.SETTINGS -> {
                            SettingsScreen(
                                uiState = uiState,
                                onMasterVolumeChange = viewModel::setMasterVolume,
                                onPadVolumeChange = viewModel::setIndividualPadVolume,
                                onUpdateEffects = viewModel::updateEffectsConfig,
                                onUpdateMidiNote = viewModel::updateMidiNoteForPad,
                                onExportBackupUri = viewModel::exportBackup,
                                onInspectBackupUri = viewModel::inspectBackupForRestore,
                                onConfirmRestore = viewModel::confirmBackupRestore,
                                onDismissBackupPreview = viewModel::dismissBackupPreview,
                                onImportExternalBackupUri = viewModel::importExternalBackup,
                                onDismissExternalOutcome = viewModel::dismissExternalImportOutcome,
                                onBack = viewModel::closeSettings
                            )
                        }
                    }
                }
            }
        }
    }
}
