package com.example.backup

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.Bank
import com.example.data.model.BundledSoundCatalog
import com.example.data.model.PadConfig
import com.example.data.model.Patch
import com.example.ui.theme.DefaultPadColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

sealed class ExternalImportOutcome {
    data class Imported(
        val patch: Patch,
        val sourceFormat: String,
        val notes: String
    ) : ExternalImportOutcome()

    data class Unsupported(
        val detectedModelOrFormat: String,
        val technicalReason: String
    ) : ExternalImportOutcome()
}

/**
 * Separate External Octapad Backup Import Framework.
 *
 * Supports open pad-map JSON/CSV kits and transparently inspects proprietary hardware dumps
 * (such as Roland SPD-20/SPD-30 binary backups) without falsely claiming full binary conversion.
 */
class ExternalBackupImporter(private val context: Context) {

    suspend fun inspectAndConvert(
        uri: Uri,
        targetBank: Bank,
        targetPatchNumber: Int
    ): ExternalImportOutcome = withContext(Dispatchers.IO) {
        try {
            val fileName = queryFileName(uri) ?: "external_patch"
            val ext = fileName.substringAfterLast('.', "").lowercase()
            val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@withContext ExternalImportOutcome.Unsupported(
                    "Unreadable File",
                    "Could not open '$fileName' from device storage."
                )

            if (rawBytes.isEmpty()) {
                return@withContext ExternalImportOutcome.Unsupported(
                    "Empty File",
                    "The selected file '$fileName' contains 0 bytes."
                )
            }

            // 1. Detect Roland SPD-20 / SPD-30 / SPD-SX proprietary binary formats
            val headerAscii = rawBytes.take(32).map { b ->
                val c = b.toInt() and 0xFF
                if (c in 32..126) c.toChar() else '.'
            }.joinToString("")

            if (ext in setOf("spd", "prm", "s20", "s30") ||
                headerAscii.contains("ROLAND", ignoreCase = true) ||
                headerAscii.contains("SPD-", ignoreCase = true)
            ) {
                return@withContext ExternalImportOutcome.Unsupported(
                    detectedModelOrFormat = "Roland SPD Series Proprietary Binary ($ext)",
                    technicalReason = "Proprietary Roland SPD-20/SPD-30 binary patch files store internal ROM instrument indices and hardware-specific DSP parameter blocks that are not publicly documented and cannot be mapped 1:1 to Android WAV samples. To migrate a kit, export a JSON/CSV pad map or import individual WAV samples via Patch Editor -> Add Sample."
                )
            }

            // 2. Try open JSON kit format ({"name": "...", "pads": [{"pad":1, "sound":"...", "volume":0.9}]})
            val text = rawBytes.toString(Charsets.UTF_8).trim()
            if (text.startsWith("{")) {
                val parsed = tryParseOpenJsonKit(text, targetBank, targetPatchNumber)
                if (parsed != null) {
                    return@withContext ExternalImportOutcome.Imported(
                        patch = parsed,
                        sourceFormat = "Open Octapad Kit JSON",
                        notes = "Mapped ${parsed.pads.size} pads from '$fileName' to ${targetBank.label} Patch $targetPatchNumber."
                    )
                }
            }

            // 3. Try CSV pad-map format (padIndex/number, soundName, volume, pitch)
            if (ext == "csv" || (text.contains(",") && text.lines().size >= 2)) {
                val parsedCsv = tryParseCsvKit(fileName, text, targetBank, targetPatchNumber)
                if (parsedCsv != null) {
                    return@withContext ExternalImportOutcome.Imported(
                        patch = parsedCsv,
                        sourceFormat = "CSV Pad Map",
                        notes = "Mapped CSV pad definitions from '$fileName' into ${targetBank.label} Patch $targetPatchNumber."
                    )
                }
            }

            ExternalImportOutcome.Unsupported(
                detectedModelOrFormat = "Unknown Format (.$ext)",
                technicalReason = "File '$fileName' is neither an Octapad 20 Pro backup (.zip) nor a recognized JSON/CSV external pad mapping."
            )
        } catch (e: Exception) {
            ExternalImportOutcome.Unsupported(
                detectedModelOrFormat = "Parse Error",
                technicalReason = e.message ?: "Failed to inspect external backup file."
            )
        }
    }

    private fun tryParseOpenJsonKit(
        text: String,
        targetBank: Bank,
        targetPatchNumber: Int
    ): Patch? {
        return try {
            val obj = JSONObject(text)
            if (obj.optString("schema") == BackupManager.SCHEMA_ID) {
                return null // Native backups should go through BackupManager
            }
            val kitName = obj.optString("name", "Imported Kit").take(28).ifBlank { "Imported Kit" }
            val padsArr = obj.optJSONArray("pads") ?: return null
            val mappedPads = MutableList(8) { idx ->
                val fallback = BundledSoundCatalog.sounds[idx % BundledSoundCatalog.sounds.size]
                PadConfig(
                    padIndex = idx,
                    soundId = fallback.id,
                    soundName = fallback.displayName,
                    borderColorHex = DefaultPadColors[idx]
                )
            }
            for (i in 0 until minOf(padsArr.length(), 8)) {
                val p = padsArr.getJSONObject(i)
                val padIdx = p.optInt("padIndex", p.optInt("pad", i + 1) - 1).coerceIn(0, 7)
                val requestedSound = p.optString("sound", p.optString("soundName", ""))
                val matched = matchBundledSoundByName(requestedSound)
                mappedPads[padIdx] = mappedPads[padIdx].copy(
                    soundId = matched.id,
                    soundName = matched.displayName,
                    volume = p.optDouble("volume", 0.9).toFloat().coerceIn(0f, 1f),
                    pitch = p.optDouble("pitch", 1.0).toFloat().coerceIn(0.5f, 2.0f),
                    pan = p.optDouble("pan", 0.0).toFloat().coerceIn(-1f, 1f),
                    enabled = p.optBoolean("enabled", true)
                )
            }
            Patch(
                bank = targetBank,
                number = targetPatchNumber,
                name = kitName,
                pads = mappedPads,
                updatedAt = System.currentTimeMillis()
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun tryParseCsvKit(
        fileName: String,
        text: String,
        targetBank: Bank,
        targetPatchNumber: Int
    ): Patch? {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null
        val mappedPads = MutableList(8) { idx ->
            val fallback = BundledSoundCatalog.sounds[idx % BundledSoundCatalog.sounds.size]
            PadConfig(
                padIndex = idx,
                soundId = fallback.id,
                soundName = fallback.displayName,
                borderColorHex = DefaultPadColors[idx]
            )
        }
        var matchedAny = false
        lines.forEach { line ->
            val cols = line.split(",").map { it.trim() }
            val padNum = cols.getOrNull(0)?.toIntOrNull()
            if (padNum != null && padNum in 1..8) {
                val soundQuery = cols.getOrNull(1) ?: ""
                val matched = matchBundledSoundByName(soundQuery)
                val vol = cols.getOrNull(2)?.toFloatOrNull()?.coerceIn(0f, 1f) ?: 0.9f
                val pitch = cols.getOrNull(3)?.toFloatOrNull()?.coerceIn(0.5f, 2.0f) ?: 1.0f
                mappedPads[padNum - 1] = mappedPads[padNum - 1].copy(
                    soundId = matched.id,
                    soundName = matched.displayName,
                    volume = vol,
                    pitch = pitch
                )
                matchedAny = true
            }
        }
        if (!matchedAny) return null
        val name = fileName.substringBeforeLast('.').take(28).ifBlank { "External Kit" }
        return Patch(
            bank = targetBank,
            number = targetPatchNumber,
            name = name,
            pads = mappedPads,
            updatedAt = System.currentTimeMillis()
        )
    }

    private fun matchBundledSoundByName(query: String) =
        BundledSoundCatalog.sounds.firstOrNull {
            it.id.equals(query, ignoreCase = true) ||
                it.displayName.equals(query, ignoreCase = true) ||
                it.displayName.contains(query, ignoreCase = true)
        } ?: BundledSoundCatalog.sounds.first()

    private fun queryFileName(uri: Uri): String? {
        if (uri.scheme == "file") return uri.lastPathSegment
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) c.getString(idx) else null
            } else null
        }
    }
}
