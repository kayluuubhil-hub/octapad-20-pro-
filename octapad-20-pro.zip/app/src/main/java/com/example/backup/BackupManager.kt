package com.example.backup

import android.content.Context
import android.net.Uri
import com.example.data.PatchRepository
import com.example.data.model.AudioEffectsConfig
import com.example.data.model.Bank
import com.example.data.model.CustomSample
import com.example.data.model.PadConfig
import com.example.data.model.Patch
import com.example.ui.theme.DefaultPadColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class BackupPreview(
    val schema: String,
    val formatVersion: Int,
    val exportedAt: Long,
    val patchCount: Int,
    val customSampleCount: Int,
    val patches: List<Patch>,
    val customSamples: List<CustomSample>,
    val samplePayloads: Map<String, ByteArray>, // sampleId.ext -> bytes
    val effectsConfig: AudioEffectsConfig?
)

enum class RestoreMode {
    REPLACE_ALL,
    MERGE_CUSTOM_ONLY
}

class BackupManager(
    private val context: Context,
    private val repository: PatchRepository
) {

    companion object {
        const val SCHEMA_ID = "octapad20pro.backup"
        const val FORMAT_VERSION = 1
        private const val MANIFEST_ENTRY = "patches_v1.json"
    }

    suspend fun exportBackupToUri(
        destinationUri: Uri,
        effectsConfig: AudioEffectsConfig
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val patches = repository.getAllPatches()
            val customSamples = repository.getAllCustomSamples()
            val json = buildManifestJson(patches, customSamples, effectsConfig)

            context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                ZipOutputStream(out).use { zip ->
                    zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                    zip.write(json.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()

                    customSamples.forEach { sample ->
                        val f = File(sample.filePath)
                        if (f.exists() && f.canRead()) {
                            val ext = f.extension.ifBlank { "wav" }
                            zip.putNextEntry(ZipEntry("samples/${sample.sampleId}.$ext"))
                            f.inputStream().use { input -> input.copyTo(zip) }
                            zip.closeEntry()
                        }
                    }
                }
            } ?: return@withContext Result.failure(
                IllegalStateException("Could not open destination file for backup export.")
            )

            Result.success("Exported ${patches.size} patches and ${customSamples.size} custom samples.")
        } catch (e: Exception) {
            Result.failure(Exception("Backup export failed: ${e.message}", e))
        }
    }

    suspend fun inspectBackupFromUri(sourceUri: Uri): Result<BackupPreview> = withContext(Dispatchers.IO) {
        try {
            var manifestString: String? = null
            val samplePayloads = mutableMapOf<String, ByteArray>()

            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        if (!entry.isDirectory) {
                            val baos = ByteArrayOutputStream()
                            val buf = ByteArray(8192)
                            while (true) {
                                val r = zip.read(buf)
                                if (r <= 0) break
                                baos.write(buf, 0, r)
                            }
                            if (name == MANIFEST_ENTRY || name == "manifest.json") {
                                manifestString = baos.toString(Charsets.UTF_8.name())
                            } else if (name.startsWith("samples/") && !name.contains("..")) {
                                val fileName = name.removePrefix("samples/")
                                samplePayloads[fileName] = baos.toByteArray()
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: return@withContext Result.failure(
                IllegalStateException("Unable to read selected backup file.")
            )

            val rawJson = manifestString ?: return@withContext Result.failure(
                IllegalArgumentException("Invalid backup archive: missing $MANIFEST_ENTRY.")
            )

            val preview = parseManifestJson(rawJson, samplePayloads)
            Result.success(preview)
        } catch (e: Exception) {
            Result.failure(Exception("Invalid backup file: ${e.message}", e))
        }
    }

    suspend fun applyBackupPreview(
        preview: BackupPreview,
        mode: RestoreMode
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val samplesDir = File(context.filesDir, "custom_samples").apply { mkdirs() }
            val restoredPathByOldPath = mutableMapOf<String, String>()

            preview.customSamples.forEach { sample ->
                val ext = File(sample.filePath).extension.ifBlank { "wav" }
                val key = "${sample.sampleId}.$ext"
                val bytes = preview.samplePayloads[key]
                if (bytes != null && bytes.isNotEmpty()) {
                    val targetFile = File(samplesDir, key)
                    FileOutputStream(targetFile).use { it.write(bytes) }
                    restoredPathByOldPath[sample.filePath] = targetFile.absolutePath
                    repository.addCustomSample(sample.copy(filePath = targetFile.absolutePath))
                }
            }

            val remappedPatches = preview.patches.map { patch ->
                patch.copy(
                    pads = patch.pads.map { pad ->
                        val remappedPath = pad.customSamplePath?.let { restoredPathByOldPath[it] ?: it }
                        pad.copy(customSamplePath = remappedPath)
                    }
                )
            }

            val toSave = when (mode) {
                RestoreMode.REPLACE_ALL -> remappedPatches
                RestoreMode.MERGE_CUSTOM_ONLY -> {
                    val existing = repository.getAllPatches().associateBy { it.bank to it.number }
                    remappedPatches.filter { incoming ->
                        val cur = existing[incoming.bank to incoming.number]
                        cur == null || incoming.updatedAt > cur.updatedAt || incoming.pads.any { it.isCustomSample }
                    }
                }
            }

            if (toSave.isNotEmpty()) {
                repository.savePatchesBulk(toSave)
            }

            Result.success("Restored ${toSave.size} patches (${mode.name.lowercase().replace('_', ' ')}).")
        } catch (e: Exception) {
            Result.failure(Exception("Restore failed: ${e.message}", e))
        }
    }

    fun buildManifestJson(
        patches: List<Patch>,
        customSamples: List<CustomSample>,
        effectsConfig: AudioEffectsConfig
    ): String {
        val root = JSONObject()
        root.put("schema", SCHEMA_ID)
        root.put("version", FORMAT_VERSION)
        root.put("exportedAt", System.currentTimeMillis())

        val fxObj = JSONObject().apply {
            put("effectsEnabled", effectsConfig.effectsEnabled)
            put("reverbLevel", effectsConfig.reverbLevel.toDouble())
            put("delayLevel", effectsConfig.delayLevel.toDouble())
            put("bassBoost", effectsConfig.bassBoost.toDouble())
            put("midGain", effectsConfig.midGain.toDouble())
            put("trebleGain", effectsConfig.trebleGain.toDouble())
        }
        root.put("effects", fxObj)

        val samplesArr = JSONArray()
        customSamples.forEach { s ->
            samplesArr.put(
                JSONObject().apply {
                    put("sampleId", s.sampleId)
                    put("displayName", s.displayName)
                    put("filePath", s.filePath)
                    put("mimeType", s.mimeType)
                    put("durationMs", s.durationMs)
                    put("fileSizeBytes", s.fileSizeBytes)
                    put("createdAt", s.createdAt)
                }
            )
        }
        root.put("customSamples", samplesArr)

        val patchesArr = JSONArray()
        patches.forEach { patch ->
            val padsArr = JSONArray()
            patch.pads.forEach { pad ->
                padsArr.put(
                    JSONObject().apply {
                        put("padIndex", pad.padIndex)
                        put("soundId", pad.soundId)
                        put("soundName", pad.soundName)
                        put("isCustomSample", pad.isCustomSample)
                        put("customSamplePath", pad.customSamplePath ?: "")
                        put("volume", pad.volume.toDouble())
                        put("pitch", pad.pitch.toDouble())
                        put("pan", pad.pan.toDouble())
                        put("enabled", pad.enabled)
                        put("borderColorHex", pad.borderColorHex)
                    }
                )
            }
            patchesArr.put(
                JSONObject().apply {
                    put("bank", patch.bank.id)
                    put("number", patch.number)
                    put("name", patch.name)
                    put("isFavorite", patch.isFavorite)
                    put("updatedAt", patch.updatedAt)
                    put("pads", padsArr)
                }
            )
        }
        root.put("patches", patchesArr)
        return root.toString(2)
    }

    fun parseManifestJson(
        rawJson: String,
        samplePayloads: Map<String, ByteArray> = emptyMap()
    ): BackupPreview {
        val root = JSONObject(rawJson)
        val schema = root.optString("schema", "")
        if (schema != SCHEMA_ID) {
            throw IllegalArgumentException("Unrecognized backup schema '$schema'.")
        }
        val version = root.optInt("version", 0)
        if (version !in 1..FORMAT_VERSION) {
            throw IllegalArgumentException("Unsupported backup version v$version.")
        }
        val exportedAt = root.optLong("exportedAt", 0L)

        val fxObj = root.optJSONObject("effects")
        val fx = fxObj?.let {
            AudioEffectsConfig(
                effectsEnabled = it.optBoolean("effectsEnabled", false),
                reverbLevel = it.optDouble("reverbLevel", 0.2).toFloat(),
                delayLevel = it.optDouble("delayLevel", 0.0).toFloat(),
                bassBoost = it.optDouble("bassBoost", 0.0).toFloat(),
                midGain = it.optDouble("midGain", 0.0).toFloat(),
                trebleGain = it.optDouble("trebleGain", 0.0).toFloat()
            )
        }

        val samples = mutableListOf<CustomSample>()
        val samplesArr = root.optJSONArray("customSamples") ?: JSONArray()
        for (i in 0 until samplesArr.length()) {
            val o = samplesArr.getJSONObject(i)
            samples.add(
                CustomSample(
                    sampleId = o.getString("sampleId"),
                    displayName = o.getString("displayName"),
                    filePath = o.getString("filePath"),
                    mimeType = o.optString("mimeType", "audio/wav"),
                    durationMs = o.optLong("durationMs", 0L),
                    fileSizeBytes = o.optLong("fileSizeBytes", 0L),
                    createdAt = o.optLong("createdAt", 0L)
                )
            )
        }

        val patches = mutableListOf<Patch>()
        val patchesArr = root.optJSONArray("patches") ?: JSONArray()
        for (i in 0 until patchesArr.length()) {
            val po = patchesArr.getJSONObject(i)
            val bank = Bank.fromId(po.optString("bank", "A"))
            val number = po.getInt("number").coerceIn(1, 100)
            val padsArr = po.getJSONArray("pads")
            val pads = mutableListOf<PadConfig>()
            for (j in 0 until padsArr.length()) {
                val p = padsArr.getJSONObject(j)
                val padIndex = p.getInt("padIndex").coerceIn(0, 7)
                val customPath = p.optString("customSamplePath", "").ifBlank { null }
                pads.add(
                    PadConfig(
                        padIndex = padIndex,
                        soundId = p.optString("soundId", "kick_punch"),
                        soundName = p.optString("soundName", "Punch Kick"),
                        isCustomSample = p.optBoolean("isCustomSample", false),
                        customSamplePath = customPath,
                        volume = p.optDouble("volume", 0.9).toFloat().coerceIn(0f, 1f),
                        pitch = p.optDouble("pitch", 1.0).toFloat().coerceIn(0.5f, 2.0f),
                        pan = p.optDouble("pan", 0.0).toFloat().coerceIn(-1f, 1f),
                        enabled = p.optBoolean("enabled", true),
                        borderColorHex = p.optLong("borderColorHex", DefaultPadColors[padIndex])
                    )
                )
            }
            patches.add(
                Patch(
                    bank = bank,
                    number = number,
                    name = po.optString("name", "Patch $number"),
                    isFavorite = po.optBoolean("isFavorite", false),
                    pads = pads.sortedBy { it.padIndex },
                    updatedAt = po.optLong("updatedAt", 0L)
                )
            )
        }

        return BackupPreview(
            schema = schema,
            formatVersion = version,
            exportedAt = exportedAt,
            patchCount = patches.size,
            customSampleCount = samples.size,
            patches = patches,
            customSamples = samples,
            samplePayloads = samplePayloads,
            effectsConfig = fx
        )
    }
}
