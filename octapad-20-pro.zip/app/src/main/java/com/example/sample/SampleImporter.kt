package com.example.sample

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import com.example.audio.AudioEngine
import com.example.data.model.CustomSample
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class SampleImporter(
    private val context: Context,
    private val audioEngine: AudioEngine
) {

    companion object {
        private const val MAX_SAMPLE_BYTES = 15L * 1024L * 1024L // 15 MB per SoundPool-friendly sample
        private val SUPPORTED_EXTENSIONS = setOf("wav", "mp3", "ogg")
        private val SUPPORTED_MIMES = setOf(
            "audio/wav", "audio/x-wav", "audio/wave", "audio/vnd.wave",
            "audio/mpeg", "audio/mp3",
            "audio/ogg", "application/ogg", "audio/vorbis"
        )
    }

    suspend fun importFromUri(uri: Uri): Result<CustomSample> = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            val rawMime = resolver.getType(uri)?.lowercase() ?: ""
            val originalName = queryDisplayName(uri) ?: "custom_sample.wav"
            val ext = originalName.substringAfterLast('.', "").lowercase()

            if (ext.isNotEmpty() && ext !in SUPPORTED_EXTENSIONS && rawMime !in SUPPORTED_MIMES) {
                return@withContext Result.failure(
                    IllegalArgumentException("Unsupported format. Please choose a WAV, MP3, or OGG audio file.")
                )
            }

            val finalExt = when {
                ext in SUPPORTED_EXTENSIONS -> ext
                rawMime.contains("mpeg") || rawMime.contains("mp3") -> "mp3"
                rawMime.contains("ogg") -> "ogg"
                else -> "wav"
            }

            val samplesDir = File(context.filesDir, "custom_samples").apply { mkdirs() }
            val sampleId = UUID.randomUUID().toString()
            val destFile = File(samplesDir, "$sampleId.$finalExt")

            var totalBytes = 0L
            resolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    val buf = ByteArray(8192)
                    while (true) {
                        val read = input.read(buf)
                        if (read <= 0) break
                        totalBytes += read
                        if (totalBytes > MAX_SAMPLE_BYTES) {
                            destFile.delete()
                            return@withContext Result.failure(
                                IllegalArgumentException("Audio file exceeds 15 MB limit for low-latency SoundPool playback.")
                            )
                        }
                        output.write(buf, 0, read)
                    }
                }
            } ?: return@withContext Result.failure(
                IllegalStateException("Could not open selected audio file from storage.")
            )

            if (totalBytes < 44L) {
                destFile.delete()
                return@withContext Result.failure(
                    IllegalArgumentException("Selected audio file is empty or damaged.")
                )
            }

            // Validate audio header / track via MediaExtractor
            val durationMs = validateAudioFile(destFile, finalExt)
            if (durationMs < 0L) {
                destFile.delete()
                return@withContext Result.failure(
                    IllegalArgumentException("Invalid or corrupted audio stream in '$originalName'.")
                )
            }

            val loaded = audioEngine.loadCustomSample(destFile.absolutePath)
            if (!loaded) {
                destFile.delete()
                return@withContext Result.failure(
                    IllegalStateException("Audio engine rejected '$originalName'. Try a standard 16-bit WAV, MP3, or OGG.")
                )
            }

            val cleanName = originalName.substringBeforeLast('.').ifBlank { "Custom Sample" }.take(32)
            val mime = when (finalExt) {
                "mp3" -> "audio/mpeg"
                "ogg" -> "audio/ogg"
                else -> "audio/wav"
            }

            Result.success(
                CustomSample(
                    sampleId = sampleId,
                    displayName = cleanName,
                    filePath = destFile.absolutePath,
                    mimeType = mime,
                    durationMs = durationMs,
                    fileSizeBytes = totalBytes,
                    createdAt = System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "Failed to import audio sample.", e))
        }
    }

    private fun validateAudioFile(file: File, ext: String): Long {
        val header = ByteArray(44)
        val readBytes = file.inputStream().use { it.read(header) }
        if (readBytes < 12) return -1L

        val riff = String(header, 0, 4, Charsets.US_ASCII)
        val wave = String(header, 8, 4, Charsets.US_ASCII)
        if (ext == "wav") {
            if (riff != "RIFF" || wave != "WAVE" || readBytes < 44) return -1L
            val byteRate = ((header[28].toInt() and 0xFF)) or
                ((header[29].toInt() and 0xFF) shl 8) or
                ((header[30].toInt() and 0xFF) shl 16) or
                ((header[31].toInt() and 0xFF) shl 24)
            if (byteRate <= 0) return -1L
            val estimatedDataBytes = (file.length() - 44L).coerceAtLeast(1L)
            return ((estimatedDataBytes * 1000L) / byteRate.toLong()).coerceAtLeast(10L)
        }

        if (ext == "ogg" && riff != "OggS") {
            return -1L
        }

        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(file.absolutePath)
            var audioDurationMs = -1L
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    val durUs = if (format.containsKey(MediaFormat.KEY_DURATION)) {
                        format.getLong(MediaFormat.KEY_DURATION)
                    } else 100_000L
                    audioDurationMs = (durUs / 1000L).coerceAtLeast(10L)
                    break
                }
            }
            audioDurationMs
        } catch (_: Exception) {
            -1L
        } finally {
            try {
                extractor.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        if (uri.scheme == "file") return uri.lastPathSegment
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) c.getString(idx) else null
            } else null
        }
    }
}
