package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import com.example.data.model.AudioEffectsConfig
import com.example.data.model.AudioEngineStatus
import com.example.data.model.BundledSoundCatalog
import com.example.data.model.CustomSample
import com.example.data.model.PadConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicIntegerArray
import java.util.concurrent.atomic.AtomicLongArray

class AudioEngine(
    private val context: Context,
    val soundPoolManager: SoundPoolManager = SoundPoolManager(context)
) {

    companion object {
        // 18ms per-pad anti-bounce threshold prevents accidental hardware double-triggers
        // while allowing rapid rolls (>55 hits/sec) and simultaneous multi-touch across pads.
        private const val DEBOUNCE_MS = 18L
    }

    private val audioManager: AudioManager? =
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    @Volatile
    private var masterVolume: Float = 0.90f

    @Volatile
    private var effectsConfig: AudioEffectsConfig = AudioEffectsConfig()

    @Volatile
    private var focusDuckMultiplier: Float = 1.0f

    @Volatile
    private var hasFocus: Boolean = false

    @Volatile
    private var initialized: Boolean = false

    private val padVolumes = FloatArray(8) { 0.90f }
    private val lastTriggerTimesMs = AtomicLongArray(8)
    private val lastStreamIds = AtomicIntegerArray(8)

    private var audioFocusRequest: AudioFocusRequest? = null

    private val _status = MutableStateFlow(AudioEngineStatus())
    val status: StateFlow<AudioEngineStatus> = _status.asStateFlow()

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                focusDuckMultiplier = 1.0f
                hasFocus = true
                updateStatus()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                focusDuckMultiplier = 0.35f
                updateStatus()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                focusDuckMultiplier = 0.0f
                hasFocus = false
                updateStatus()
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                hasFocus = false
                updateStatus()
            }
        }
    }

    fun initializeAudio() {
        if (initialized) return
        val ok = soundPoolManager.initialize()
        if (ok) {
            initialized = true
            requestAudioFocus()
            val (sr, fpb) = soundPoolManager.queryAudioHardwareInfo()
            _status.update {
                it.copy(
                    isInitialized = true,
                    totalBundledCount = BundledSoundCatalog.sounds.size,
                    sampleRateHz = sr,
                    framesPerBuffer = fpb,
                    hasAudioFocus = hasFocus,
                    effectsHardwareSupported = soundPoolManager.isHardwareEffectsSupported
                )
            }
        }
    }

    fun preloadSamples(customSamples: List<CustomSample> = emptyList()) {
        if (!initialized) initializeAudio()
        soundPoolManager.preloadBundledSamples()
        if (customSamples.isNotEmpty()) {
            soundPoolManager.loadCustomSamples(customSamples)
        }
        updateStatus()
    }

    fun loadCustomSample(filePath: String): Boolean {
        if (!initialized) initializeAudio()
        val loaded = soundPoolManager.loadCustomSample(filePath)
        updateStatus()
        return loaded
    }

    /**
     * Direct low-latency pad trigger. Executed synchronously from touch/MIDI callbacks:
     * zero DB calls, zero file I/O, zero coroutines on the dry hit path.
     */
    fun playPad(padConfig: PadConfig, velocity: Float = 1.0f): Int {
        if (!initialized || !padConfig.enabled) return 0
        val idx = padConfig.padIndex
        if (idx !in 0..7) return 0

        val nowMs = SystemClock.elapsedRealtime()
        val prevMs = lastTriggerTimesMs.get(idx)
        if (prevMs > 0L && (nowMs - prevMs) < DEBOUNCE_MS) {
            return 0
        }
        lastTriggerTimesMs.set(idx, nowMs)

        if (!hasFocus && focusDuckMultiplier == 0.0f) {
            // Re-request focus automatically when user resumes playing after an interruption
            focusDuckMultiplier = 1.0f
            requestAudioFocus()
        }

        val sampleKey = if (padConfig.isCustomSample && !padConfig.customSamplePath.isNullOrBlank()) {
            padConfig.customSamplePath
        } else {
            padConfig.soundId
        }

        val effectivePadVol = padVolumes[idx].coerceIn(0f, 1f)
        val combinedGain = (masterVolume * effectivePadVol * velocity.coerceIn(0.05f, 1.0f) * focusDuckMultiplier)
            .coerceIn(0f, 1f)

        val pan = padConfig.pan.coerceIn(-1f, 1f)
        val leftGain = if (pan > 0f) combinedGain * (1f - pan) else combinedGain
        val rightGain = if (pan < 0f) combinedGain * (1f + pan) else combinedGain
        val rate = padConfig.pitch.coerceIn(0.5f, 2.0f)

        val streamId = soundPoolManager.play(
            sampleKey = sampleKey,
            leftVolume = leftGain,
            rightVolume = rightGain,
            rate = rate,
            priority = 1
        )
        if (streamId > 0) {
            lastStreamIds.set(idx, streamId)
        }

        val fx = effectsConfig
        if (fx.effectsEnabled && fx.delayLevel > 0.01f && combinedGain > 0.01f) {
            soundPoolManager.scheduleDelayTaps(sampleKey, leftGain, rightGain, rate, fx.delayLevel)
        }

        return streamId
    }

    fun previewSample(soundId: String, customPath: String? = null, pitch: Float = 1.0f): Int {
        if (!initialized) initializeAudio()
        val key = if (!customPath.isNullOrBlank()) customPath else soundId
        val vol = (masterVolume * 0.9f).coerceIn(0f, 1f)
        return soundPoolManager.play(key, vol, vol, pitch.coerceIn(0.5f, 2.0f), priority = 1)
    }

    fun stopPad(padIndex: Int) {
        if (padIndex !in 0..7) return
        val streamId = lastStreamIds.getAndSet(padIndex, 0)
        if (streamId > 0) {
            soundPoolManager.stopStream(streamId)
        }
    }

    fun setPadVolume(padIndex: Int, volume: Float) {
        if (padIndex !in 0..7) return
        val clamped = volume.coerceIn(0f, 1f)
        padVolumes[padIndex] = clamped
        val streamId = lastStreamIds.get(padIndex)
        if (streamId > 0) {
            val g = (masterVolume * clamped * focusDuckMultiplier).coerceIn(0f, 1f)
            soundPoolManager.setStreamVolume(streamId, g, g)
        }
    }

    fun syncPatchPadVolumes(pads: List<PadConfig>) {
        pads.forEach { pad ->
            if (pad.padIndex in 0..7) {
                padVolumes[pad.padIndex] = pad.volume.coerceIn(0f, 1f)
            }
        }
    }

    fun setMasterVolume(volume: Float) {
        masterVolume = volume.coerceIn(0f, 1f)
        for (i in 0..7) {
            val streamId = lastStreamIds.get(i)
            if (streamId > 0) {
                val g = (masterVolume * padVolumes[i] * focusDuckMultiplier).coerceIn(0f, 1f)
                soundPoolManager.setStreamVolume(streamId, g, g)
            }
        }
    }

    fun getMasterVolume(): Float = masterVolume

    fun setEffectsConfig(config: AudioEffectsConfig) {
        effectsConfig = config
        soundPoolManager.applyHardwareEffects(config)
    }

    fun refreshStatus() {
        updateStatus()
    }

    private fun updateStatus() {
        _status.update {
            it.copy(
                isInitialized = initialized,
                loadedBundledCount = soundPoolManager.loadedCountFlow.value.coerceAtLeast(
                    if (initialized) BundledSoundCatalog.sounds.size else 0
                ),
                totalBundledCount = BundledSoundCatalog.sounds.size,
                loadedCustomCount = soundPoolManager.customLoadedCountFlow.value,
                hasAudioFocus = hasFocus,
                effectsHardwareSupported = soundPoolManager.isHardwareEffectsSupported
            )
        }
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        val res = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setWillPauseWhenDucked(false)
                .setOnAudioFocusChangeListener(focusChangeListener)
                .build()
            audioFocusRequest = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                focusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
        hasFocus = (res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
    }

    fun releaseAudio() {
        val am = audioManager
        if (am != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(focusChangeListener)
            }
        }
        soundPoolManager.release()
        initialized = false
        hasFocus = false
        updateStatus()
    }
}
