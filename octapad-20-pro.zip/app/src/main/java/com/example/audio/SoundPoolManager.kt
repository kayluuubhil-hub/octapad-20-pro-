package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.os.Handler
import android.os.HandlerThread
import com.example.data.model.AudioEffectsConfig
import com.example.data.model.BundledSoundCatalog
import com.example.data.model.CustomSample
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class SoundPoolManager(private val context: Context) {

    companion object {
        private const val MAX_STREAMS = 16
    }

    private var soundPool: SoundPool? = null
    private val sampleMap = ConcurrentHashMap<String, Int>() // key (soundId or custom path) -> SoundPool sampleId
    private val loadedSampleIds: MutableSet<Int> = Collections.newSetFromMap(ConcurrentHashMap())

    private val loadedBundledCounter = AtomicInteger(0)
    private val loadedCustomCounter = AtomicInteger(0)

    private var delayThread: HandlerThread? = null
    private var delayHandler: Handler? = null

    private var equalizer: Equalizer? = null
    private var presetReverb: PresetReverb? = null
    @Volatile
    var isHardwareEffectsSupported: Boolean = false
        private set

    private val _loadedCountFlow = MutableStateFlow(0)
    val loadedCountFlow: StateFlow<Int> = _loadedCountFlow.asStateFlow()

    private val _customLoadedCountFlow = MutableStateFlow(0)
    val customLoadedCountFlow: StateFlow<Int> = _customLoadedCountFlow.asStateFlow()

    fun initialize(): Boolean {
        if (soundPool != null) return true
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val pool = SoundPool.Builder()
            .setMaxStreams(MAX_STREAMS)
            .setAudioAttributes(attrs)
            .build()

        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSampleIds.add(sampleId)
                val bundledCount = BundledSoundCatalog.sounds.count { sound ->
                    val sid = sampleMap[sound.id]
                    sid != null && loadedSampleIds.contains(sid)
                }
                loadedBundledCounter.set(bundledCount)
                _loadedCountFlow.value = bundledCount

                val customCount = loadedSampleIds.size - bundledCount
                loadedCustomCounter.set(customCount.coerceAtLeast(0))
                _customLoadedCountFlow.value = customCount.coerceAtLeast(0)
            }
        }

        soundPool = pool
        if (delayThread == null) {
            delayThread = HandlerThread("OctapadDelayThread").apply { start() }
            delayHandler = Handler(delayThread!!.looper)
        }
        initHardwareEffectsSafe()
        return true
    }

    private fun initHardwareEffectsSafe() {
        try {
            val eq = Equalizer(0, 0).apply { enabled = false }
            val rev = PresetReverb(0, 0).apply { enabled = false }
            equalizer = eq
            presetReverb = rev
            isHardwareEffectsSupported = true
        } catch (_: Throwable) {
            isHardwareEffectsSupported = false
        }
    }

    fun preloadBundledSamples() {
        val pool = soundPool ?: return
        BundledSoundCatalog.sounds.forEach { sound ->
            if (!sampleMap.containsKey(sound.id)) {
                try {
                    val sampleId = pool.load(context, sound.rawResId, 1)
                    if (sampleId > 0) {
                        sampleMap[sound.id] = sampleId
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    fun loadCustomSamples(samples: List<CustomSample>) {
        val pool = soundPool ?: return
        samples.forEach { sample ->
            loadCustomSamplePath(pool, sample.filePath)
        }
    }

    fun loadCustomSample(filePath: String): Boolean {
        val pool = soundPool ?: return false
        return loadCustomSamplePath(pool, filePath)
    }

    private fun loadCustomSamplePath(pool: SoundPool, filePath: String): Boolean {
        if (filePath.isBlank()) return false
        if (sampleMap.containsKey(filePath)) return true
        val file = File(filePath)
        if (!file.exists() || !file.canRead()) return false
        return try {
            val sampleId = pool.load(filePath, 1)
            if (sampleId > 0) {
                sampleMap[filePath] = sampleId
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun play(
        sampleKey: String,
        leftVolume: Float,
        rightVolume: Float,
        rate: Float,
        priority: Int = 1
    ): Int {
        val pool = soundPool ?: return 0
        val sampleId = sampleMap[sampleKey] ?: return 0
        // Note: on Robolectric or before async callback fires, sampleId > 0 is valid
        return pool.play(
            sampleId,
            leftVolume.coerceIn(0f, 1f),
            rightVolume.coerceIn(0f, 1f),
            priority,
            0,
            rate.coerceIn(0.5f, 2.0f)
        )
    }

    fun scheduleDelayTaps(
        sampleKey: String,
        leftVolume: Float,
        rightVolume: Float,
        rate: Float,
        delayLevel: Float
    ) {
        val handler = delayHandler ?: return
        val level = delayLevel.coerceIn(0f, 1f)
        if (level <= 0.01f) return
        val tap1L = (leftVolume * level * 0.55f).coerceIn(0f, 1f)
        val tap1R = (rightVolume * level * 0.55f).coerceIn(0f, 1f)
        val tap2L = (leftVolume * level * 0.28f).coerceIn(0f, 1f)
        val tap2R = (rightVolume * level * 0.28f).coerceIn(0f, 1f)

        handler.postDelayed({
            play(sampleKey, tap1L, tap1R, rate, priority = 0)
        }, 185L)
        handler.postDelayed({
            play(sampleKey, tap2L, tap2R, rate, priority = 0)
        }, 370L)
    }

    fun stopStream(streamId: Int) {
        if (streamId > 0) {
            soundPool?.stop(streamId)
        }
    }

    fun setStreamVolume(streamId: Int, leftVolume: Float, rightVolume: Float) {
        if (streamId > 0) {
            soundPool?.setVolume(streamId, leftVolume.coerceIn(0f, 1f), rightVolume.coerceIn(0f, 1f))
        }
    }

    fun applyHardwareEffects(config: AudioEffectsConfig) {
        try {
            val eq = equalizer
            if (eq != null) {
                eq.enabled = config.effectsEnabled
                if (config.effectsEnabled) {
                    val bands = eq.numberOfBands.toInt()
                    val range = eq.bandLevelRange
                    val minLv = range[0].toInt()
                    val maxLv = range[1].toInt()
                    for (b in 0 until bands) {
                        val freqHz = eq.getCenterFreq(b.toShort()) / 1000
                        val normGain = when {
                            freqHz < 250 -> config.bassBoost
                            freqHz < 2200 -> config.midGain
                            else -> config.trebleGain
                        }.coerceIn(-1f, 1f)
                        val levelMb = if (normGain >= 0f) {
                            (normGain * maxLv).toInt()
                        } else {
                            (-normGain * minLv).toInt()
                        }.coerceIn(minLv, maxLv).toShort()
                        eq.setBandLevel(b.toShort(), levelMb)
                    }
                }
            }
            val rev = presetReverb
            if (rev != null) {
                rev.enabled = config.effectsEnabled && config.reverbLevel > 0.05f
                if (rev.enabled) {
                    val preset = when {
                        config.reverbLevel < 0.25f -> PresetReverb.PRESET_SMALLROOM
                        config.reverbLevel < 0.50f -> PresetReverb.PRESET_MEDIUMROOM
                        config.reverbLevel < 0.75f -> PresetReverb.PRESET_LARGEROOM
                        else -> PresetReverb.PRESET_LARGEHALL
                    }
                    rev.preset = preset
                }
            }
        } catch (_: Throwable) {
            // Gracefully ignore on hardware/OS configurations disallowing global session 0 effects
        }
    }

    fun queryAudioHardwareInfo(): Pair<Int, Int> {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val sr = am?.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 44100
        val fpb = am?.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256
        return sr to fpb
    }

    fun release() {
        delayHandler?.removeCallbacksAndMessages(null)
        delayThread?.quitSafely()
        delayThread = null
        delayHandler = null
        try {
            equalizer?.release()
            presetReverb?.release()
        } catch (_: Throwable) {
        }
        equalizer = null
        presetReverb = null
        soundPool?.release()
        soundPool = null
        sampleMap.clear()
        loadedSampleIds.clear()
        loadedBundledCounter.set(0)
        loadedCustomCounter.set(0)
        _loadedCountFlow.value = 0
        _customLoadedCountFlow.value = 0
    }
}
