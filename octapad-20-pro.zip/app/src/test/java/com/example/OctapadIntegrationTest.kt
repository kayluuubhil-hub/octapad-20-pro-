package com.example

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.audio.AudioEngine
import com.example.backup.BackupManager
import com.example.backup.ExternalBackupImporter
import com.example.backup.ExternalImportOutcome
import com.example.backup.RestoreMode
import com.example.data.PatchRepository
import com.example.data.db.OctapadDatabase
import com.example.data.db.PresetPatchSeeder
import com.example.data.model.AudioEffectsConfig
import com.example.data.model.Bank
import com.example.midi.MidiManager
import com.example.sample.SampleImporter
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w960dp-h540dp-land-xxhdpi")
class OctapadIntegrationTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `main screen renders header, patch bar, and all 8 pads in landscape`() {
        composeRule.waitUntil(timeoutMillis = 5000) {
            runCatching {
                composeRule.onNodeWithTag("octapad_main_screen").assertExists()
                true
            }.getOrDefault(false)
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithText("OCTAPAD 20 PRO").assertIsDisplayed()
        composeRule.onNodeWithText("PROFESSIONAL MOBILE OCTAPAD").assertIsDisplayed()
        composeRule.onNodeWithTag("bank_a_button").assertIsDisplayed()
        composeRule.onNodeWithTag("bank_b_button").assertIsDisplayed()
        composeRule.onNodeWithTag("save_button").assertIsDisplayed()
        composeRule.onNodeWithTag("load_button").assertIsDisplayed()
        composeRule.onNodeWithTag("edit_button").assertIsDisplayed()
        composeRule.onNodeWithTag("copy_button").assertIsDisplayed()
        composeRule.onNodeWithTag("clear_button").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_button").assertIsDisplayed()

        for (i in 1..8) {
            composeRule.onNodeWithTag("pad_$i").assertIsDisplayed()
        }

        // Switching Bank A -> Bank B updates active patch label cleanly
        composeRule.onNodeWithTag("bank_b_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Salpuri Pro").assertIsDisplayed()

        // Navigate to Settings and back
        composeRule.onNodeWithTag("settings_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_back_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("octapad_main_screen").assertIsDisplayed()
    }

    @Test
    fun `database seeds 200 independent patches and supports save copy clear and restart persistence`(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbFile = context.getDatabasePath("test_octapad_persist.db")
        dbFile.delete()

        val db1 = Room.databaseBuilder(context, OctapadDatabase::class.java, dbFile.name)
            .allowMainThreadQueries()
            .build()
        val repo1 = PatchRepository(db1.patchDao())
        repo1.ensureSeeded()

        val allInitial = repo1.getAllPatches()
        assertEquals(200, allInitial.size)
        assertEquals(100, allInitial.count { it.bank == Bank.A })
        assertEquals(100, allInitial.count { it.bank == Bank.B })
        assertEquals("Salpuri", repo1.getPatch(Bank.A, 1)?.name)
        assertEquals("Salpuri Pro", repo1.getPatch(Bank.B, 1)?.name)

        // Independent edit of Bank A Patch 7 does not affect Bank A Patch 8 or Bank B Patch 7
        val patch7 = repo1.getPatch(Bank.A, 7)!!
        val originalB7Name = repo1.getPatch(Bank.B, 7)!!.name
        val editedPads = patch7.pads.map { p ->
            if (p.padIndex == 0) p.copy(volume = 0.45f, pitch = 1.25f) else p
        }
        repo1.savePatch(patch7.copy(name = "Live Navratri Custom", isFavorite = true, pads = editedPads))

        assertNotEquals("Live Navratri Custom", repo1.getPatch(Bank.A, 8)?.name)
        assertEquals(originalB7Name, repo1.getPatch(Bank.B, 7)?.name)

        // Copy Bank A Patch 7 -> Bank B Patch 42
        val copied = repo1.copyPatch(Bank.A, 7, Bank.B, 42)
        assertNotNull(copied)
        assertEquals("Live Navratri Custom", repo1.getPatch(Bank.B, 42)?.name)

        // Clear only Bank B Patch 42
        repo1.clearPatch(Bank.B, 42)
        assertEquals("Custom Patch 42", repo1.getPatch(Bank.B, 42)?.name)
        assertEquals("Live Navratri Custom", repo1.getPatch(Bank.A, 7)?.name)

        db1.close()

        // Reopen database simulating app restart
        val db2 = Room.databaseBuilder(context, OctapadDatabase::class.java, dbFile.name)
            .allowMainThreadQueries()
            .build()
        val repo2 = PatchRepository(db2.patchDao())
        val restored = repo2.getPatch(Bank.A, 7)!!
        assertEquals("Live Navratri Custom", restored.name)
        assertTrue(restored.isFavorite)
        assertEquals(0.45f, restored.pads[0].volume, 0.001f)
        assertEquals(1.25f, restored.pads[0].pitch, 0.001f)
        db2.close()
        dbFile.delete()
    }

    @Test
    fun `audio engine plays all 8 pads, enforces debounce, and handles master and pad volumes`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = AudioEngine(context)
        engine.initializeAudio()
        engine.preloadSamples()

        val pads = PresetPatchSeeder.defaultCleanPads()
        assertEquals(8, pads.size)

        engine.setMasterVolume(0.80f)
        assertEquals(0.80f, engine.getMasterVolume(), 0.001f)

        // Trigger all 8 pads simultaneously (multi-touch scenario)
        pads.forEach { pad ->
            engine.setPadVolume(pad.padIndex, 0.85f)
            engine.playPad(pad, 1.0f)
        }

        // Immediate double-trigger within 18ms on same pad is prevented cleanly
        val bounceResult = engine.playPad(pads[0], 1.0f)
        assertEquals(0, bounceResult)

        // Advancing Robolectric clock past 18ms allows rapid repeated hit
        SystemClock.sleep(25)
        engine.playPad(pads[0], 0.9f)

        assertTrue(engine.status.value.isInitialized)
        engine.releaseAudio()
        assertFalse(engine.status.value.isInitialized)
    }

    @Test
    fun `backup export and restore preserves 200 patches and custom samples`(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, OctapadDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = PatchRepository(db.patchDao())
        repo.ensureSeeded()

        val target = repo.getPatch(Bank.A, 12)!!
        repo.savePatch(target.copy(name = "Backup Test Kit"))

        val backupManager = BackupManager(context, repo)
        val zipFile = File(context.cacheDir, "test_backup.zip")
        zipFile.delete()
        val resExport = backupManager.exportBackupToUri(
            Uri.fromFile(zipFile),
            AudioEffectsConfig(effectsEnabled = true, delayLevel = 0.35f)
        )
        assertTrue(resExport.isSuccess)
        assertTrue(zipFile.exists() && zipFile.length() > 100L)

        // Mutate patch locally, then restore from backup
        repo.savePatch(target.copy(name = "Overwritten Locally"))
        val previewRes = backupManager.inspectBackupFromUri(Uri.fromFile(zipFile))
        assertTrue(previewRes.isSuccess)
        val preview = previewRes.getOrThrow()
        assertEquals(200, preview.patchCount)

        val restoreRes = backupManager.applyBackupPreview(preview, RestoreMode.REPLACE_ALL)
        assertTrue(restoreRes.isSuccess)
        assertEquals("Backup Test Kit", repo.getPatch(Bank.A, 12)?.name)

        db.close()
        zipFile.delete()
    }

    @Test
    fun `sample importer validates wav and rejects corrupted files`(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = AudioEngine(context)
        engine.initializeAudio()
        val importer = SampleImporter(context, engine)

        // 1. Corrupt empty file should fail cleanly
        val badFile = File(context.cacheDir, "corrupt.wav").apply { writeBytes(ByteArray(10)) }
        val badRes = importer.importFromUri(Uri.fromFile(badFile))
        assertTrue(badRes.isFailure)

        // 2. Valid PCM WAV file succeeds
        val goodWav = File(context.cacheDir, "valid_test.wav")
        goodWav.writeBytes(createMinimalValidWav(4410))
        val goodRes = importer.importFromUri(Uri.fromFile(goodWav))
        assertTrue(goodRes.isSuccess)
        assertEquals("valid_test", goodRes.getOrThrow().displayName)

        badFile.delete()
        goodWav.delete()
        engine.releaseAudio()
    }

    @Test
    fun `external backup importer handles open json and rejects roland proprietary spd honestly`(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val importer = ExternalBackupImporter(context)

        val spdFile = File(context.cacheDir, "kit01.spd").apply {
            writeBytes("ROLAND SPD-30 BINARY DUMP".toByteArray())
        }
        val spdRes = importer.inspectAndConvert(Uri.fromFile(spdFile), Bank.A, 50)
        assertTrue(spdRes is ExternalImportOutcome.Unsupported)

        val jsonKit = File(context.cacheDir, "external_kit.json").apply {
            writeText("""{"name":"Garba External","pads":[{"pad":1,"sound":"Dhol Bass","volume":0.95},{"pad":2,"sound":"Manjira Ring","volume":0.85}]}""")
        }
        val jsonRes = importer.inspectAndConvert(Uri.fromFile(jsonKit), Bank.A, 50)
        assertTrue(jsonRes is ExternalImportOutcome.Imported)
        val importedPatch = (jsonRes as ExternalImportOutcome.Imported).patch
        assertEquals("Garba External", importedPatch.name)
        assertEquals("dhol_bass", importedPatch.pads[0].soundId)
        assertEquals("manjira_ring", importedPatch.pads[1].soundId)

        spdFile.delete()
        jsonKit.delete()
    }

    @Test
    fun `midi manager routes note on bytes to configured pad`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var triggeredPad = -1
        var triggeredVel = 0f
        val midi = MidiManager(context) { padIdx, vel, _ ->
            triggeredPad = padIdx
            triggeredVel = vel
        }

        // Default map: MIDI Note 36 -> PAD 1 (index 0)
        midi.parseMidiBytes(byteArrayOf(0x90.toByte(), 36, 127), 0, 3)
        assertEquals(0, triggeredPad)
        assertEquals(1.0f, triggeredVel, 0.01f)

        // Default map: MIDI Note 38 -> PAD 2 (index 1)
        midi.parseMidiBytes(byteArrayOf(0x90.toByte(), 38, 64), 0, 3)
        assertEquals(1, triggeredPad)
        assertTrue(triggeredVel in 0.45f..0.55f)
    }

    private fun createMinimalValidWav(numSamples: Int): ByteArray {
        val dataSize = numSamples * 2
        val buf = ByteBuffer.allocate(44 + dataSize).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray())
        buf.putInt(36 + dataSize)
        buf.put("WAVE".toByteArray())
        buf.put("fmt ".toByteArray())
        buf.putInt(16)
        buf.putShort(1) // PCM
        buf.putShort(1) // Mono
        buf.putInt(44100)
        buf.putInt(44100 * 2)
        buf.putShort(2)
        buf.putShort(16)
        buf.put("data".toByteArray())
        buf.putInt(dataSize)
        for (i in 0 until numSamples) {
            buf.putShort((Math.sin(2.0 * Math.PI * 220.0 * i / 44100.0) * 16000).toInt().toShort())
        }
        return buf.array()
    }
}
